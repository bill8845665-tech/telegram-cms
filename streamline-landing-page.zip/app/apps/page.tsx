import TelegramNavbar from "@/components/telegram/navbar"
import TelegramFooter from "@/components/telegram/footer"
import { Smartphone, Monitor, Globe, Database, Github, Download, Shield, ExternalLink } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Telegram Apps - Download for iOS, Android, Desktop & Web",
  description:
    "Download official Telegram apps for iPhone, iPad, Android, macOS, Windows, Linux and Web. Open source, reproducible builds, and TDLib for developers.",
  keywords:
    "telegram download, telegram app, telegram ios, telegram android, telegram desktop, telegram web, telegram tdlib",
}

export default function AppsPage() {
  return (
    <div className="min-h-screen bg-white">
      <TelegramNavbar />

      <main className="pt-24 pb-16">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          {/* Header */}
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4">Telegram Applications</h1>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              Telegram apps are open source and support reproducible builds. Anyone can independently verify that
              Telegram apps you download from App Store or Google Play were built using the exact same code that we
              publish.
            </p>
          </div>

          {/* Official Apps Grid */}
          <div className="grid md:grid-cols-3 gap-6 mb-16">
            {/* Mobile Apps */}
            <div className="bg-card rounded-2xl p-6 border border-border shadow-sm">
              <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mb-4">
                <Smartphone className="w-6 h-6 text-primary" />
              </div>
              <h2 className="text-xl font-semibold text-card-foreground mb-4">Mobile apps</h2>
              <ul className="space-y-3">
                <li>
                  <Link href="#" className="text-primary hover:underline flex items-center gap-2">
                    Telegram for Android
                    <ExternalLink className="w-4 h-4" />
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-primary hover:underline flex items-center gap-2">
                    Telegram for iPhone and iPad
                    <ExternalLink className="w-4 h-4" />
                  </Link>
                </li>
              </ul>
            </div>

            {/* Desktop Apps */}
            <div className="bg-card rounded-2xl p-6 border border-border shadow-sm">
              <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mb-4">
                <Monitor className="w-6 h-6 text-primary" />
              </div>
              <h2 className="text-xl font-semibold text-card-foreground mb-4">Desktop apps</h2>
              <ul className="space-y-3">
                <li>
                  <Link href="#" className="text-primary hover:underline flex items-center gap-2">
                    Telegram for Windows/Mac/Linux
                    <ExternalLink className="w-4 h-4" />
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-primary hover:underline flex items-center gap-2">
                    Telegram for macOS
                    <ExternalLink className="w-4 h-4" />
                  </Link>
                </li>
              </ul>
            </div>

            {/* Web Apps */}
            <div className="bg-card rounded-2xl p-6 border border-border shadow-sm">
              <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mb-4">
                <Globe className="w-6 h-6 text-primary" />
              </div>
              <h2 className="text-xl font-semibold text-card-foreground mb-4">Web apps</h2>
              <ul className="space-y-3">
                <li>
                  <Link href="#" className="text-primary hover:underline flex items-center gap-2">
                    Telegram WebA
                    <ExternalLink className="w-4 h-4" />
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-primary hover:underline flex items-center gap-2">
                    Telegram WebK
                    <ExternalLink className="w-4 h-4" />
                  </Link>
                </li>
              </ul>
            </div>
          </div>

          {/* TDLib Section */}
          <div className="bg-card rounded-2xl p-8 border border-border shadow-sm mb-16">
            <div className="flex items-start gap-6">
              <div className="w-14 h-14 bg-primary/10 rounded-xl flex items-center justify-center flex-shrink-0">
                <Database className="w-7 h-7 text-primary" />
              </div>
              <div>
                <h2 className="text-2xl font-semibold text-card-foreground mb-2">Telegram Database Library (TDLib)</h2>
                <p className="text-muted-foreground mb-4">
                  TDLib – a cross-platform client designed to facilitate creating custom apps on the Telegram platform.
                </p>
                <p className="text-muted-foreground mb-4">
                  <strong>Telegram X for Android</strong> – a slick experimental Telegram client based on TDLib.
                </p>
                <div className="flex flex-wrap gap-3">
                  <Button variant="outline" className="gap-2 bg-transparent">
                    <Github className="w-4 h-4" />
                    View on GitHub
                  </Button>
                </div>
              </div>
            </div>
          </div>

          {/* Unofficial Apps */}
          <div className="mb-16">
            <h2 className="text-2xl font-semibold text-foreground mb-6">Unofficial apps</h2>
            <div className="grid md:grid-cols-3 gap-4">
              <div className="bg-card rounded-xl p-5 border border-border">
                <h3 className="font-medium text-card-foreground mb-2">Unigram</h3>
                <p className="text-sm text-muted-foreground mb-3">A client optimized for Windows (based on TDLib)</p>
                <Link href="#" className="text-sm text-primary hover:underline">
                  Learn more
                </Link>
              </div>
              <div className="bg-card rounded-xl p-5 border border-border">
                <h3 className="font-medium text-card-foreground mb-2">Telegram CLI</h3>
                <p className="text-sm text-muted-foreground mb-3">Linux Command-line interface for Telegram</p>
                <Link href="#" className="text-sm text-primary hover:underline">
                  Learn more
                </Link>
              </div>
              <div className="bg-card rounded-xl p-5 border border-border">
                <h3 className="font-medium text-card-foreground mb-2">MadelineProto</h3>
                <p className="text-sm text-muted-foreground mb-3">A PHP MTProto Telegram client</p>
                <Link href="#" className="text-sm text-primary hover:underline">
                  Learn more
                </Link>
              </div>
            </div>
          </div>

          {/* Source Code Section */}
          <div className="mb-16">
            <h2 className="text-2xl font-semibold text-foreground mb-6">Source code</h2>
            <p className="text-muted-foreground mb-8 max-w-3xl">
              This code allows security researchers to fully evaluate our end-to-end encryption implementation. It is
              also possible to independently verify that Telegram apps available on Google Play and App Store are built
              using the same code that we publish on GitHub.
            </p>

            <div className="grid md:grid-cols-2 gap-4">
              {/* TDLib */}
              <div className="bg-card rounded-xl p-5 border border-border">
                <h3 className="font-semibold text-card-foreground mb-1">Telegram Database Library</h3>
                <p className="text-sm text-muted-foreground mb-3">
                  Cross-platform library for building custom Telegram apps.
                </p>
                <p className="text-xs text-muted-foreground mb-3">Licensed under Boost 1.0</p>
                <Button variant="outline" size="sm" className="gap-2 bg-transparent">
                  <Github className="w-4 h-4" />
                  GitHub
                </Button>
              </div>

              {/* Android */}
              <div className="bg-card rounded-xl p-5 border border-border">
                <h3 className="font-semibold text-card-foreground mb-1">Telegram for Android</h3>
                <p className="text-sm text-muted-foreground mb-3">
                  Official Android App, see Google Play Market page for full description.
                </p>
                <p className="text-xs text-muted-foreground mb-3">Licensed under GNU GPL v. 2 or later</p>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" className="gap-2 bg-transparent">
                    <Github className="w-4 h-4" />
                    GitHub
                  </Button>
                  <Button variant="outline" size="sm" className="gap-2 bg-transparent">
                    <Download className="w-4 h-4" />
                    APK
                  </Button>
                </div>
              </div>

              {/* iOS */}
              <div className="bg-card rounded-xl p-5 border border-border">
                <h3 className="font-semibold text-card-foreground mb-1">Telegram for iOS</h3>
                <p className="text-sm text-muted-foreground mb-3">Official iOS client for iPhone and iPad.</p>
                <p className="text-xs text-muted-foreground mb-3">Licensed under GNU GPL v. 2 or later</p>
                <Button variant="outline" size="sm" className="gap-2 bg-transparent">
                  <Github className="w-4 h-4" />
                  GitHub
                </Button>
              </div>

              {/* macOS */}
              <div className="bg-card rounded-xl p-5 border border-border">
                <h3 className="font-semibold text-card-foreground mb-1">Telegram for macOS</h3>
                <p className="text-sm text-muted-foreground mb-3">Native macOS client.</p>
                <p className="text-xs text-muted-foreground mb-3">Licensed under GNU GPL v. 2</p>
                <Button variant="outline" size="sm" className="gap-2 bg-transparent">
                  <Github className="w-4 h-4" />
                  GitHub
                </Button>
              </div>

              {/* Desktop */}
              <div className="bg-card rounded-xl p-5 border border-border">
                <h3 className="font-semibold text-card-foreground mb-1">Telegram Desktop</h3>
                <p className="text-sm text-muted-foreground mb-3">Qt-based desktop client. Mac, Windows, Linux.</p>
                <p className="text-xs text-muted-foreground mb-3">Licensed under GNU GPL v. 3</p>
                <Button variant="outline" size="sm" className="gap-2 bg-transparent">
                  <Github className="w-4 h-4" />
                  GitHub
                </Button>
              </div>

              {/* Web K */}
              <div className="bg-card rounded-xl p-5 border border-border">
                <h3 className="font-semibold text-card-foreground mb-1">Telegram Web, Version K</h3>
                <p className="text-sm text-muted-foreground mb-3">Mac, Windows, Linux, Mobile.</p>
                <p className="text-xs text-muted-foreground mb-3">Licensed under GNU GPL v. 3</p>
                <Button variant="outline" size="sm" className="gap-2 bg-transparent">
                  <Github className="w-4 h-4" />
                  GitHub
                </Button>
              </div>

              {/* Web A */}
              <div className="bg-card rounded-xl p-5 border border-border">
                <h3 className="font-semibold text-card-foreground mb-1">Telegram Web, Version A</h3>
                <p className="text-sm text-muted-foreground mb-3">Mac, Windows, Linux, Mobile.</p>
                <p className="text-xs text-muted-foreground mb-3">Licensed under GNU GPL v. 3</p>
                <Button variant="outline" size="sm" className="gap-2 bg-transparent">
                  <Github className="w-4 h-4" />
                  GitHub
                </Button>
              </div>

              {/* Telegram X */}
              <div className="bg-card rounded-xl p-5 border border-border">
                <h3 className="font-semibold text-card-foreground mb-1">Telegram X for Android</h3>
                <p className="text-sm text-muted-foreground mb-3">
                  Alternative Telegram client for Android based on TDLib.
                </p>
                <p className="text-xs text-muted-foreground mb-3">Licensed under GPL v.3.0</p>
                <Button variant="outline" size="sm" className="gap-2 bg-transparent">
                  <Github className="w-4 h-4" />
                  GitHub
                </Button>
              </div>
            </div>
          </div>

          {/* Bug Bounty Program */}
          <div className="bg-primary/5 rounded-2xl p-8 border border-primary/20">
            <div className="flex items-start gap-6">
              <div className="w-14 h-14 bg-primary/10 rounded-xl flex items-center justify-center flex-shrink-0">
                <Shield className="w-7 h-7 text-primary" />
              </div>
              <div>
                <h2 className="text-2xl font-semibold text-foreground mb-2">Bug Bounty Program</h2>
                <p className="text-muted-foreground mb-4">
                  Telegram welcomes developers and the security research community to audit its services, code and
                  protocol seeking vulnerabilities or security-related issues.
                </p>
                <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
                  Learn more about Bug Bounty
                </Button>
              </div>
            </div>
          </div>
        </div>
      </main>

      <TelegramFooter />
    </div>
  )
}
