"use client"

import TelegramNavbar from "@/components/telegram/navbar"
import TelegramFooter from "@/components/telegram/footer"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

const faqSections = [
  {
    title: "General Questions",
    items: [
      {
        question: "What is Telegram? What do I do here?",
        answer:
          "Telegram is a messaging app with a focus on speed and security, it's super-fast, simple and free. You can use Telegram on all your devices at the same time — your messages sync seamlessly across any number of your phones, tablets or computers. Telegram is one of the top 5 most downloaded apps in the world with over 1 billion active users.\n\nWith Telegram, you can send messages, photos, videos and files of any type (doc, zip, mp3, etc), as well as create groups for up to 200,000 people or channels for broadcasting to unlimited audiences. You can write to your phone contacts and find people by their usernames. As a result, Telegram is like SMS and email combined — and can take care of all your personal or business messaging needs. In addition to this, we support end-to-end encrypted voice and video calls, as well as voice chats in groups for thousands of participants.",
      },
      {
        question: "Who is Telegram for?",
        answer:
          "Telegram is for everyone who wants fast and reliable messaging and calls. Business users and small teams may like the large groups, usernames, desktop apps and powerful file sharing options.\n\nSince Telegram groups can have up to 200,000 members, we support replies, mentions and hashtags that help maintain order and keep communication in large communities efficient. You can appoint admins with advanced tools to help these communities prosper in peace. Public groups can be joined by anyone and are powerful platforms for discussions and collecting feedback.",
      },
      {
        question: "How is Telegram different from WhatsApp?",
        answer:
          "Unlike WhatsApp, Telegram is a cloud-based messenger with seamless sync. As a result, you can access your messages from several devices at once, including tablets and computers, and share an unlimited number of photos, videos and files (doc, zip, mp3, etc.) of up to 2 GB each.\n\nTelegram needs less than 100 MB on your device – you can keep all your media in the cloud without deleting things – simply clear your cache to free up space.\n\nThanks to Telegram's multi-data center infrastructure and encryption, it is faster and way more secure. On top of that, private messaging on Telegram is free and will stay free — no ads, no subscription fees, forever.",
      },
      {
        question: "How old is Telegram?",
        answer:
          "Telegram for iOS was launched on August 14, 2013. The alpha version of Telegram for Android officially launched on October 20, 2013. More and more Telegram clients appear, built by independent developers using Telegram's open platform.",
      },
      {
        question: "Which devices can I use?",
        answer:
          "You can use Telegram on smartphones, tablets, and even computers. We have apps for iOS (11.0 and above), Android (6.0 and up), a native macOS app and a universal desktop app for Windows, macOS, and Linux. Telegram Web can also help to quickly do something on the go.\n\nYou can log in to Telegram from as many of your devices as you like — all at the same time. Just use your main mobile phone number to log in everywhere, your cloud chats will sync instantly.",
      },
      {
        question: "Who are the people behind Telegram?",
        answer:
          "Telegram is supported by Pavel Durov and his brother Nikolai. Pavel supports Telegram financially and ideologically while Nikolai's input is technological. To make Telegram possible, Nikolai developed a unique custom data protocol, which is open, secure and optimized for work with multiple data-centers. As a result, Telegram combines security, reliability and speed on any network.",
      },
      {
        question: "Where is Telegram based?",
        answer:
          "The Telegram development team is based in Dubai.\n\nMost of the developers behind Telegram originally come from St. Petersburg, the city famous for its unprecedented number of highly skilled engineers. The Telegram team had to leave Russia due to local IT regulations and has tried a number of locations as its base, including Berlin, London and Singapore. We're currently happy with Dubai, although are ready to relocate again if local regulations change.",
      },
      {
        question: "How are you going to make money out of this?",
        answer:
          "We believe in fast and secure messaging that is also 100% free.\n\nFollowing a sustainable monetization plan, Telegram has implemented:\n\n• In 2021, Telegram launched Sponsored Messages – minimalist, privacy-conscious advertisements that can appear in certain public channels.\n• In 2022, Telegram launched a Premium subscription which users can purchase to both support the app and unlock additional exclusive features.\n\nThese revenue streams help us pay for infrastructure costs and developer salaries, however making profits will never be an end-goal for Telegram.",
      },
      {
        question: "What are your thoughts on internet privacy?",
        answer:
          "We think that the two most important components of Internet privacy should be:\n\n1. Protecting your private conversations from snooping third parties, such as officials, employers, etc.\n2. Protecting your personal data from third parties, such as marketers, advertisers, etc.\n\nTelegram's aim is to create a truly free messenger, with a revolutionary privacy policy.",
      },
      {
        question: "What about GDPR?",
        answer:
          "The General Data Protection Regulation (GDPR) came into force in Europe on May 25, 2018. Since taking back our right to privacy was the reason we made Telegram, there wasn't much we had to change. We don't use your data for ad targeting, we don't sell it to others, and we're not part of any \"family of companies.\"\n\nTelegram only keeps the information it needs to function as a feature-rich cloud service. For example, your cloud chats – so that you can access them from any devices without using third-party backups, or your contacts – so that you can rely on your existing social graph when messaging people on Telegram.",
      },
    ],
  },
  {
    title: "Telegram Basics",
    items: [
      {
        question: "Who can I write to?",
        answer:
          "You can write to people who are in your phone contacts and have Telegram. Another way of contacting people is to type their Telegram username into the search field – you don't need to know their phone number to do this.",
      },
      {
        question: "Who can contact me?",
        answer:
          "People can contact you on Telegram if they know your phone number or if you message them first.\n\nIf they don't know your phone number, they can find you in these cases:\n\n• When you both are members of the same group.\n• If you set a public username. Others can use Global Search and find you by your username.",
      },
      {
        question: "What do the check marks mean?",
        answer:
          "One check — message delivered to the Telegram cloud and your friend has been notified if he allows notifications.\nTwo checks — message read (your friend opened Telegram and opened the conversation with the message).\n\nWe don't have a 'delivered to device' status for messages because Telegram can run on as many devices as you want. So which particular one would that check mean?",
      },
      {
        question: "Can I hide my 'last seen' time?",
        answer:
          "You can choose who sees this info in Privacy and Security settings.\n\nRemember that you won't see Last Seen timestamps for people with whom you don't share your own. You will, however, see an approximate last seen value. There are four possible approximate values:\n\n• Last seen recently — covers anything between 1 second and 2-3 days\n• Last seen within a week — between 2-3 and seven days\n• Last seen within a month — between 6-7 days and a month\n• Last seen a long time ago — more than a month",
      },
      {
        question: "Can I delete my messages?",
        answer:
          "Yes. You can always delete any messages you sent or received for both sides in any one-on-one conversation (in groups, it's still your own messages only). You can also clear the entire chat history on both ends. On Telegram, deleted messages do not leave a mark in the chat.\n\nTogether with privacy settings for forwarded messages, this makes exchanging Telegram messages similar to talking face to face (without a tape recorder).",
      },
      {
        question: "Can I make calls via Telegram?",
        answer:
          "Yes! You can make end-to-end encrypted Voice Calls and Video Calls.\n\nIf you want more participants, try starting a Voice Chat in one of the groups you created. Voice Chats add a live layer of ephemeral talk to the group. They can be used as virtual office spaces for teams or informal lounges for any community.",
      },
      {
        question: "How do I invite my friends?",
        answer:
          "iOS: The basic invitations are simple SMS messages. They will be charged as standard outgoing SMS by your carrier (unless sent via iMessage). Naturally, you have other options to bring your friends here.\n\nAndroid: Open the app menu (swipe right in chat list) > Invite Friends. Then choose an application via which you would like to send out invitations.\n\nYou can give your friends a t.me link with your username so that they can easily find you on Telegram even if they don't have your phone number.\n\nThe link: https://telegram.org/dl/",
      },
    ],
  },
  {
    title: "Groups and Channels",
    items: [
      {
        question: "What makes Telegram groups cool?",
        answer:
          "Telegram groups can have up to 200,000 members each and are extremely powerful communication tools. Here are a few key features:\n\n• Unified history: Edit your messages after posting, delete them so that they disappear for everyone.\n• Cross-platform availability: Access your messages anytime, from any number of your mobile or desktop devices.\n• Instant search: Find the message you're looking for, even among millions.\n• Replies, mentions, hashtags: Easily trace a conversation and keep communication efficient.\n• Smart notifications: Mute the group to get notifications only when people mention you or reply to your messages.\n• Pinned messages: Pin any message to be displayed at the top of the chat screen.\n• Moderation tools: Appoint administrators that can mass-delete messages, control membership, and pin important messages.\n• File sharing: Send and receive files of any type, up to 2 GB in size each.",
      },
      {
        question: "What's the difference between groups and channels?",
        answer:
          "Telegram groups are ideal for sharing stuff with friends and family or collaboration in small teams. But groups can also grow very large and support communities of up to 200,000 members. You can make any group public, toggle persistent history to control whether or not new members have access to earlier messages and appoint administrators with granular privileges.\n\nChannels are a tool for broadcasting messages to large audiences. In fact, a channel can have an unlimited number of subscribers. When you post in a channel, the message is signed with the channel's name and photo and not your own. Each message in a channel has a view counter that gets updated when the message is viewed.",
      },
      {
        question: "How do I create a group?",
        answer:
          "iOS: Start a new message (tap the icon in the top right corner in Chats) > 'New Group'.\n\nAndroid: Tap the circular pencil icon in the chat list > 'New Group'.\n\nTelegram Desktop: Click the menu button in the top left corner > 'New Group'.",
      },
      {
        question: "How do I add more members? What's an invite link?",
        answer:
          "You can add your contacts, or using search by username.\n\nIt is easy to migrate existing groups to Telegram by sending people an invite link. To create an invite link, go to Group Info > Add Member > Invite to Group via Link.\n\nAnyone who has Telegram installed will be able to join your group by following this link. If you choose to revoke the link, it will stop working immediately.",
      },
    ],
  },
  {
    title: "Usernames and t.me",
    items: [
      {
        question: "What are usernames? How do I get one?",
        answer:
          "You can set a public username on Telegram. It then becomes possible for other users to find you by that username – you will appear in search under 'global results'. Please note that people who find you will be able to send you messages, even if they don't know your number.\n\nYou can set up a username in Settings and use the universal search box in the chat list to search for chats, messages, and usernames.",
      },
      {
        question: "What are Collectible Usernames?",
        answer:
          "Collectible usernames work just like basic usernames, they appear in Global Search results and have their own links that can be used outside of Telegram: username.t.me and t.me/username.\n\nThey can be bought and sold through third-party platforms like Fragment, giving a simple and secure way to acquire and exchange valuable Telegram domains. Acquiring a collectible username gives permanent ownership, verified by the TON blockchain.",
      },
      {
        question: "How does t.me work?",
        answer:
          "Once you've set a username, you can give people a t.me/username or a username.t.me link. Opening either of those links on their phone will automatically fire up their Telegram app and open a chat with you. You can share username links with friends, write them on business cards or put them up on your website.\n\nThis way people can contact you on Telegram without knowing your phone number.",
      },
      {
        question: "What can I use as my username?",
        answer:
          "You can use a-z, 0-9 and underscores. Usernames are case-insensitive, but Telegram will store your capitalization preferences (e.g. Telegram and TeleGram is the same user).",
      },
      {
        question: "What do I do if my username is taken?",
        answer:
          "Telegram basic usernames are distributed on a first-come – first-serve basis.\n\nIf your desired username is already taken and it is not registered as a collectible, we can help you acquire it for your account or channel, provided that you have that same username on at least two of these services: Facebook, Twitter, Instagram.\n\nTo request a username, contact @Username_bot.",
      },
    ],
  },
  {
    title: "Security",
    items: [
      {
        question: "How secure is Telegram?",
        answer:
          "Telegram is more secure than mass market messengers like WhatsApp and Line. We are based on the MTProto protocol, built upon time-tested algorithms to make security compatible with high-speed delivery and reliability on weak connections. We are continuously working with the community to improve the security of our protocol and clients.",
      },
      {
        question: "So how do you encrypt data?",
        answer:
          "We support two layers of secure encryption. Server-client encryption is used in Cloud Chats (private and group chats), Secret Chats use an additional layer of client-client encryption. All data, regardless of type, is encrypted in the same way — be it text, media or files.\n\nOur encryption is based on 256-bit symmetric AES encryption, 2048-bit RSA encryption, and Diffie–Hellman secure key exchange.",
      },
      {
        question: "Why should I trust you?",
        answer:
          "Telegram is open, anyone can check our source code, protocol and API, see how everything works and make an informed decision. Telegram supports verifiable builds, which allow experts to independently verify that our code published on GitHub is the exact same code that is used to build the apps you download from App Store or Google Play.\n\nWe welcome security experts to audit our system and appreciate any feedback at security@telegram.org.\n\nOn top of that, Telegram's primary focus is not to bring a profit, so commercial interests will never interfere with our mission.",
      },
      {
        question: "Can Telegram protect me against everything?",
        answer:
          "Telegram can help when it comes to data transfer and secure communication. This means that all data (including media and files) that you send and receive via Telegram cannot be deciphered when intercepted by your internet service provider, owners of Wi-Fi routers you connect to, or other third parties.\n\nBut please remember that we cannot protect you from your own mother if she takes your unlocked phone without a passcode. Or from your IT-department if they access your computer at work. Or from any other people that get physical or root access to your phones or computers running Telegram.\n\nIf you have reasons to worry about your personal security, we strongly recommend using only Secret Chats in official or at least verifiable open-source apps for sensitive information, preferably with a self-destruct timer.",
      },
      {
        question: "How does 2-Step Verification work?",
        answer:
          "Logging in with an SMS code is an industry standard in messaging, but if you're looking for more security or have reasons to doubt your mobile carrier or government, we recommend protecting your cloud chats with an additional password.\n\nYou can do this in Settings > Privacy and Security > 2-Step Verification. Once enabled, you will need both an SMS code and a password to log in. You can also set up a recovery email address that will help regain access, should you forget your password.",
      },
    ],
  },
  {
    title: "Secret Chats",
    items: [
      {
        question: "How are secret chats different?",
        answer:
          "Secret chats are meant for people who want more secrecy than the average fella. All messages in secret chats use end-to-end encryption. This means only you and the recipient can read those messages — nobody else can decipher them, including us here at Telegram.\n\nOn top of this, Messages cannot be forwarded from secret chats. And when you delete messages on your side of the conversation, the app on the other side of the secret chat will be ordered to delete them as well.\n\nYou can order your messages, photos, videos and files to self-destruct in a set amount of time after they have been read or opened by the recipient.\n\nAll secret chats in Telegram are device-specific and are not part of the Telegram cloud. This means you can only access messages in a secret chat from their device of origin.",
      },
      {
        question: "How do I start a secret chat?",
        answer:
          "Open the profile of the user you want to contact. Tap on '…', then 'Start Secret Chat'.\n\nRemember that Telegram secret chats are device-specific. If you start a secret chat with a friend on one of your devices, this chat will only be available on that device. If you log out, you will lose all your secret chats. You can create as many different secret chats with the same contact as you like.",
      },
      {
        question: "How do self-destructing messages work?",
        answer:
          "The Self-Destruct Timer is available for all messages in Secret Chats and for media in private cloud chats.\n\nTo set the timer, simply tap the clock icon (in the input field on iOS, top bar on Android), and then choose the desired time limit. The clock starts ticking the moment the message is displayed on the recipient's screen (gets two check marks). As soon as the time runs out, the message disappears from both devices.\n\nPlease note that the timer in Secret Chats only applies to messages that were sent after the timer was set. It has no effect on earlier messages.",
      },
      {
        question: "What is the 'Encryption Key' thing?",
        answer:
          "When a secret chat is created, the participating devices exchange encryption keys using the so-called Diffie-Hellman key exchange. After the secure end-to-end connection has been established, we generate a picture that visualizes the encryption key for your chat. You can then compare this image with the one your friend has — if the two images are the same, you can be sure that the secret chat is secure, and no man-in-the-middle attack can succeed.\n\nAlways compare visualizations using a channel that is known to be secure — it's safest if you do this in person, in an offline meeting with the conversation partner.",
      },
      {
        question: "Why not just make all chats 'secret'?",
        answer:
          "All Telegram messages are always securely encrypted. Messages in Secret Chats use client-client encryption, while Cloud Chats use client-server/server-client encryption and are stored encrypted in the Telegram Cloud. This enables your cloud messages to be both secure and immediately accessible from any of your devices – even if you lose your device altogether.\n\nThe problem of restoring access to your chat history on a newly connected device (e.g. when you lose your phone) does not have an elegant solution in the end-to-end encryption paradigm. We opted for a third approach by offering two distinct types of chats.",
      },
    ],
  },
  {
    title: "Your Account",
    items: [
      {
        question: "Who can see my phone number?",
        answer:
          "On Telegram, you can send messages in private chats and groups without making your phone number visible. By default, your number is only visible to people who you've added to your address book as contacts. You can further modify this in Settings > Privacy and Security > Phone Number.\n\nNote that people will always see your number if they know it already and saved it in their address book.",
      },
      {
        question: "I have a new phone number, what do I do?",
        answer:
          "Each phone number is a separate account on Telegram. You have several options if you are using multiple phone numbers:\n\n• If you will no longer use the old number, simply go to Settings and change the number connected to your Telegram account to the new number.\n• If you will keep using both numbers, you can keep both accounts.",
      },
      {
        question: "How do I delete my Telegram account?",
        answer:
          "If you would like to delete your account, you can do this on the deactivation page. Deleting your account permanently removes all your messages and contacts. All groups and channels that you've created are orphaned and left without a creator but admins retain their rights.\n\nThis action must be confirmed via your Telegram account and cannot be undone.",
      },
      {
        question: "How does account self-destruction work?",
        answer:
          "Telegram is not a commercial organization, and we value our disk space greatly. If you stop using Telegram and don't come online for at least 6 months, your account will be deleted along with all messages, media, contacts and every other piece of data you store in the Telegram cloud. You can change the exact period after which your inactive account will self-destruct in Settings.",
      },
      {
        question: "My phone was stolen. What do I do?",
        answer:
          "First of all, sorry about your phone. Unfortunately, the phone number is the only way for us to identify a Telegram user at the moment. We don't collect additional information about you, so whoever has the number, has the account.\n\nGo to Settings > Devices (or Privacy and Security > Active Sessions) and terminate all other sessions. This way the person with your phone won't be able to log in again.\n\nIf you have 2-Step Verification enabled, your data is safe. You can get a new SIM card with your number and log in again.",
      },
    ],
  },
  {
    title: "Bots",
    items: [
      {
        question: "How do I create a bot?",
        answer:
          "Creating Telegram bots is super-easy, but you will need at least some skills in computer programming. If you're sure you're up to it, our Introduction for Developers is a good place to start.\n\nUnfortunately, there are no out-of-the-box ways to create a working bot if you are not a developer. But we're sure you'll soon find plenty of bots created by other people to play with.",
      },
      {
        question: "How do I get rid of a bot?",
        answer:
          "If you want to stop a bot from sending you messages, just block it – same as you would block a human user. Some Telegram clients have a 'Stop Bot' button right in the bot's profile.\n\nThat said, most bot developers offer commands that silence the bot, check the bot's /help for clues.",
      },
      {
        question: "Are bots safe?",
        answer:
          "Yes. Bots are no different from human users that you meet in groups for example. They can see your public name, username and profile pictures, and they can see messages you send to them, that's it. They can't access your last seen status and don't see your phone number (unless you decide to give it to them yourself).\n\nNaturally, any bot should be treated as a stranger — don't give them your passwords, Telegram codes or bank account numbers, even if they ask nicely. Also, be careful when opening files sent by bots, same as you would deal with ordinary humans.",
      },
    ],
  },
  {
    title: "Troubleshooting",
    items: [
      {
        question: "SMS, login, register problems",
        answer:
          "If you're having trouble logging in, please follow these steps:\n\n1. Make sure you're entering the phone number in international format.\n2. If you're not receiving SMS codes, wait for the option to get the code via a phone call.\n3. Contact your carrier to make sure they're not blocking Telegram.\n4. Try requesting the code using a different phone number.",
      },
      {
        question: "Notification problems",
        answer:
          "If you have problems with notifications, please check these settings:\n\n1. Go to Telegram Settings > Notifications and Sounds and check if notifications are on.\n2. Check that notifications are turned on for Telegram in your device settings.\n3. Make sure battery optimization/power saving is not blocking Telegram notifications.\n4. Try uninstalling and reinstalling the app.",
      },
      {
        question: "Problems with contacts",
        answer:
          "If you're missing some of your contacts, keep in mind that contacts will only show up on Telegram if they have a Telegram account.\n\nIf you're using Telegram on Android and can't find some of your contacts, please try re-syncing: go to Settings > Privacy and Security > Delete synced contacts, then Settings > Contacts > Sync Contacts.",
      },
      {
        question: "Contact Telegram Support",
        answer:
          "If you have any other questions, please contact Telegram Support (in Telegram go to Settings > Ask a question). Note that we rely on volunteers for support.\n\nIf you can't log in to your account, please use this form.\n\nYou can also reach us on Twitter: @telegram",
      },
    ],
  },
]

export default function FAQPageClient() {
  return (
    <div className="min-h-screen bg-background">
      <TelegramNavbar />

      <main className="pt-24 pb-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6">
          <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4 text-center">Telegram FAQ</h1>
          <p className="text-lg text-muted-foreground text-center mb-12">
            Find answers to frequently asked questions about Telegram
          </p>

          {/* Table of Contents */}
          <div className="bg-card rounded-xl border border-border p-6 mb-12">
            <h2 className="text-lg font-semibold text-foreground mb-4">Contents</h2>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {faqSections.map((section, index) => (
                <a key={index} href={`#section-${index}`} className="text-sm text-primary hover:underline">
                  {section.title}
                </a>
              ))}
            </div>
          </div>

          {/* FAQ Sections */}
          <div className="space-y-12">
            {faqSections.map((section, sectionIndex) => (
              <section key={sectionIndex} id={`section-${sectionIndex}`}>
                <h2 className="text-2xl font-bold text-foreground mb-6 pb-2 border-b border-border">{section.title}</h2>
                <Accordion type="single" collapsible className="space-y-3">
                  {section.items.map((item, itemIndex) => (
                    <AccordionItem
                      key={itemIndex}
                      value={`${sectionIndex}-${itemIndex}`}
                      className="border border-border rounded-lg px-4 bg-card"
                    >
                      <AccordionTrigger className="text-left text-foreground hover:text-primary hover:no-underline py-4">
                        <span className="font-medium">Q: {item.question}</span>
                      </AccordionTrigger>
                      <AccordionContent className="text-muted-foreground pb-4 whitespace-pre-line leading-relaxed">
                        {item.answer}
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </section>
            ))}
          </div>

          {/* Contact Section */}
          <div className="mt-16 text-center bg-telegram-light-blue rounded-xl p-8">
            <h2 className="text-xl font-semibold text-foreground mb-3">Still have questions?</h2>
            <p className="text-muted-foreground mb-6">
              If you can't find what you're looking for, feel free to contact us.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <a
                href="https://telegram.org/support"
                className="inline-flex items-center gap-2 bg-primary text-primary-foreground px-6 py-3 rounded-full hover:bg-primary/90 transition-colors"
              >
                Contact Support
              </a>
              <a
                href="https://twitter.com/telegram"
                className="inline-flex items-center gap-2 bg-card text-foreground px-6 py-3 rounded-full border border-border hover:border-primary transition-colors"
              >
                Follow on Twitter
              </a>
            </div>
          </div>
        </div>
      </main>

      <TelegramFooter />
    </div>
  )
}
