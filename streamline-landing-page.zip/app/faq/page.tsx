import type { Metadata } from "next"
import FAQPageClient from "./client-page"

export const metadata: Metadata = {
  title: "Telegram FAQ - Frequently Asked Questions | Telegram Messenger",
  description:
    "Find answers to frequently asked questions about Telegram. Learn about security, features, groups, channels, and how to use Telegram effectively.",
  keywords:
    "telegram faq, telegram help, telegram questions, telegram security, telegram features, how to use telegram",
}

export default function FAQPage() {
  return <FAQPageClient />
}
