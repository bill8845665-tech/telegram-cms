import type { Metadata } from "next"
import TelegramNavbar from "@/components/telegram/navbar"
import TelegramHero from "@/components/telegram/hero"
import TelegramFeatures from "@/components/telegram/features"
import TelegramApps from "@/components/telegram/apps"
import TelegramStats from "@/components/telegram/stats"
import TelegramFooter from "@/components/telegram/footer"

export const metadata: Metadata = {
  title: "Telegram Messenger - Fast, Secure, Free Messaging App",
  description:
    "Telegram is a cloud-based messaging app with over 950 million active users. Fast, secure, and synced across all your devices. Free messaging, voice and video calls, file sharing up to 2GB.",
  keywords:
    "telegram, messaging app, secure chat, cloud messaging, free messaging, video calls, voice calls, file sharing, group chat",
  openGraph: {
    title: "Telegram Messenger - A new era of messaging",
    description: "Fast, secure, and synced across all your devices. Over 950 million active users.",
    type: "website",
  },
}

export default function Home() {
  return (
    <div className="min-h-screen bg-white">
      <TelegramNavbar />
      <TelegramHero />
      <TelegramFeatures />
      <TelegramApps />
      <TelegramStats />
      <TelegramFooter />
    </div>
  )
}
