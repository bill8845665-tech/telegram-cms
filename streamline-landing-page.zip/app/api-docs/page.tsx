import type { Metadata } from "next"
import Link from "next/link"
import TelegramNavbar from "@/components/telegram/navbar"
import TelegramFooter from "@/components/telegram/footer"
import {
  Bot,
  Database,
  MessageSquare,
  Shield,
  Zap,
  Code,
  FileText,
  Settings,
  Users,
  Star,
  Gift,
  Palette,
  Bookmark,
} from "lucide-react"

const apiSections = [
  {
    id: "bot-api",
    title: "Bot API",
    icon: Bot,
    description:
      "This API allows you to connect bots to our system. Telegram Bots are special accounts that do not require an additional phone number to set up. These accounts serve as an interface for code running somewhere on your server.",
    details:
      "To use this, you don't need to know anything about how our MTProto encryption protocol works — our intermediary server will handle all encryption and communication with the Telegram API for you. You communicate with this server via a simple HTTPS-interface that offers a simplified version of the Telegram API.",
    link: { text: "Learn more about the Bot API here", url: "#" },
    extra:
      "Bot developers can also make use of our Payments API to accept payments from Telegram users around the world.",
  },
  {
    id: "tdlib",
    title: "TDLib – build your own Telegram",
    icon: Database,
    description:
      "Even if you're looking for maximum customization, you don't have to create your app from scratch. Try our Telegram Database Library (or simply TDLib), a tool for third-party developers that makes it easy to build fast, secure and feature-rich Telegram apps.",
    details:
      "TDLib takes care of all network implementation details, encryption and local data storage, so that you can dedicate more time to design, responsive interfaces and beautiful animations. TDLib supports all Telegram features and makes developing Telegram apps a breeze on any platform. It can be used on Android, iOS, Windows, macOS, Linux and virtually any other system. The library is open source and compatible with virtually any programming language.",
    link: { text: "Learn more about TDLib here", url: "#" },
  },
  {
    id: "gateway-api",
    title: "Gateway API",
    icon: MessageSquare,
    description:
      "The Telegram Gateway API allows any business, app or website to send authorization codes through Telegram instead of traditional SMS – offering a powerful and convenient way to lower costs while increasing the security and delivery speed of your codes to Telegram's 1 billion monthly active users.",
    details:
      "Users will instantly receive messages with codes in a special chat inside Telegram. Telegram's Gateway API is completely free to test.",
    link: { text: "Learn more here", url: "#" },
  },
  {
    id: "telegram-api",
    title: "Telegram API",
    icon: Code,
    description:
      "This API allows you to build your own customized Telegram clients. It is 100% open for all developers who wish to create Telegram applications on our platform.",
    details:
      "Feel free to study the open source code of existing Telegram applications for examples of how things work here. Don't forget to register your application in our system.",
    link: { text: "Register your application", url: "#" },
  },
]

const gettingStartedItems = [
  { title: "Creating an application", desc: "How to get your application identifier and create a new Telegram app." },
  { title: "User authorization", desc: "How to register a user's phone to start using the API." },
  {
    title: "Two-factor authentication",
    desc: "How to login to a user's account if they have enabled 2FA, how to change password.",
  },
  { title: "QR code login", desc: "QR code login flow." },
  { title: "Error handling", desc: "How to handle API return errors correctly." },
  {
    title: "Handling different data centers",
    desc: "How to connect to the closest DC access point for faster interaction with the API.",
  },
  { title: "Handling updates", desc: "How to subscribe to updates and handle them properly." },
  { title: "Handling PUSH-notifications", desc: "How to subscribe and handle them properly." },
  {
    title: "Channels, supergroups, gigagroups and basic groups",
    desc: "How to handle channels, supergroups, gigagroups, basic groups, and what's the difference between them.",
  },
  { title: "Forums", desc: "Telegram allows creating forums with multiple distinct topics." },
  {
    title: "Direct messages to channels",
    desc: "Telegram supports direct messages to channels, which can also be used to suggest channel posts.",
  },
  { title: "Channel statistics", desc: "Telegram offers detailed channel statistics for channels and supergroups." },
  { title: "Calling methods", desc: "Additional options for calling methods." },
  { title: "Uploading and Downloading Files", desc: "How to transfer large data batches correctly." },
  { title: "Pagination", desc: "How to fetch results from large lists of objects." },
  { title: "Client configuration", desc: "The MTProto API has multiple client configuration parameters." },
]

const securityItems = [
  { title: "Secret chats, end-to-end encryption", desc: "End-to-end-encrypted messaging." },
  { title: "Security guidelines", desc: "Important checks required in your client application." },
  { title: "Perfect Forward Secrecy", desc: "Binding temporary authorization key to permanent ones." },
  { title: "End-to-End Encryption in Voice and Video Calls", desc: "End-to-end-encrypted calls." },
]

const apiMethodItems = [
  { title: "Available method list", desc: "A list of available high-level methods." },
  { title: "API TL-schema, as JSON", desc: "Text and JSON-presentation of types and methods used in API." },
  { title: "Layer changelog", desc: "A detailed changelog of available schema versions." },
]

const botFeatures = [
  { title: "Working with bots, using the MTProto API", desc: "How to work with bots using the MTProto API." },
  { title: "Bot API dialog IDs", desc: "Convert MTProto peer IDs to bot API dialog IDs and vice versa." },
  { title: "Commands", desc: "Bots offer a set of commands that can be used by users in private, or in a chat." },
  { title: "Buttons", desc: "Users can interact with your bot via buttons or even inline buttons." },
  { title: "Menu button", desc: "Bots can choose the behavior of the menu button shown next to the text input field." },
  { title: "Inline queries", desc: "Users can interact with your bot via inline queries." },
  { title: "Games", desc: "Bots can offer users HTML5 games to play solo or to compete against each other." },
  { title: "Mini apps", desc: "Bots can offer users interactive HTML5 mini apps to completely replace any website." },
  { title: "Affiliate programs", desc: "Developers can open affiliate programs for their mini app." },
  {
    title: "Attachment menu",
    desc: "Bots can install attachment menu entries, offering conveniently accessible mini apps.",
  },
]

const contentFeatures = [
  { title: "Stories", desc: "Telegram users and channels can easily post and view stories through the API." },
  { title: "Similar channels and bots", desc: "Obtain a list of similarly themed public channels and bots." },
  { title: "Accent colors", desc: "Users and channels can change the accent color and background pattern." },
  { title: "Privacy settings", desc: "Users can specify granular privacy settings." },
  { title: "Search & filters", desc: "Apply detailed message filters while looking for messages in chats." },
  { title: "Polls", desc: "Telegram allows sending polls and quizzes." },
  { title: "Checklists", desc: "Premium users can create collaborative checklists in any chat." },
  { title: "Reactions", desc: "Users can react on any message using specific emojis." },
  { title: "Animated message effects", desc: "Adding spectacular animated effects to messages." },
  { title: "Emoji categories", desc: "Sticker, custom emoji and GIF selection UIs." },
  { title: "Emoji status", desc: "Users can set an emoticon or a custom emoji as status." },
]

const groupFeatures = [
  {
    title: "Invite links and join requests",
    desc: "Private invite links may be further enhanced with per-user join requests.",
  },
  {
    title: "Admin, banned and default rights",
    desc: "Handle admin permissions, granular bans and global permissions.",
  },
  { title: "Discussion groups", desc: "Groups can be associated to a channel as a discussion group." },
  {
    title: "Channel comments and message threads",
    desc: "Commenting on a channel post or on a generic group message.",
  },
  { title: "Admin log", desc: "A log of recent relevant supergroup and channel actions." },
  { title: "Pinned messages", desc: "Telegram allows pinning multiple messages on top of a specific chat." },
  { title: "Mentions", desc: "Mentioning other users and quickly navigating to those mentions." },
  { title: "Scheduled messages", desc: "Telegram allows scheduling messages." },
  { title: "Live geolocations", desc: "Sending the live geolocation of a user in a chat." },
]

const monetizationFeatures = [
  { title: "Telegram Stars", desc: "Virtual items that allow users to purchase digital goods and services." },
  { title: "Subscriptions", desc: "Bots and channels may create subscriptions, periodically charging users." },
  { title: "Gifts", desc: "Users can send Gifts to their friends and display them on their profile pages." },
  { title: "Paid media", desc: "Content creators can accept Stars by publishing paid photos or videos." },
  { title: "Paid messages", desc: "Telegram Stars can be used to pay for sending messages." },
  { title: "Suggested posts", desc: "A powerful monetization feature to channel administrators." },
  {
    title: "Channel and supergroup boosts",
    desc: "Premium users can grant their favorite channels additional features.",
  },
  { title: "Giveaways & gifts", desc: "Randomly distribute Telegram Premium subscriptions among followers." },
  { title: "Channel and bot ad revenue", desc: "Channel and bot owners can receive 50% of the revenue from ads." },
]

const otherFeatures = [
  { title: "Saved messages", desc: "A personal cloud storage for any messages or media." },
  { title: "Profile", desc: "Telegram offers many customization options for your profile." },
  { title: "Themes", desc: "Generating, sharing and synchronizing app themes." },
  { title: "Sponsored messages", desc: "Support for official sponsored messages in Telegram channels." },
  { title: "Fact-checks", desc: "Displaying fact-checks added to messages by independent fact-checkers." },
  { title: "Contacts", desc: "Working with contacts in the API." },
  { title: "Blocklist", desc: "Working with the blocklist." },
  { title: "Nearby users & chats", desc: "Geolocation-based features like geochats and the nearby users feature." },
  { title: "Age verification", desc: "Some legislations require age verification to view restricted content." },
  { title: "Deep links", desc: "Handle special tg:// and t.me deep links." },
  { title: "Takeout", desc: "Export all user information through the takeout API." },
]

const premiumFeatures = [
  { title: "Telegram Premium", desc: "An optional subscription service that unlocks additional exclusive features." },
  {
    title: "Telegram Business",
    desc: "Business account features like opening hours, location, quick replies, and more.",
  },
]

export const metadata: Metadata = {
  title: "Telegram API Documentation - Bot API, TDLib, Gateway API",
  description:
    "Complete Telegram API documentation for developers. Build bots with Bot API, create custom clients with TDLib, send verification codes with Gateway API, or use the full Telegram API.",
  keywords: "telegram api, bot api, tdlib, gateway api, telegram bot, telegram developer, api documentation, mtproto",
}

export default function APIPage() {
  return (
    <main className="min-h-screen bg-background">
      <TelegramNavbar />

      <div className="pt-24 pb-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6">
          {/* Header */}
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-foreground mb-4">Telegram APIs</h1>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              We offer three kinds of APIs for developers. The Bot API allows you to easily create programs that use
              Telegram messages for an interface. The Telegram API and TDLib allow you to build your own customized
              Telegram clients. You are welcome to use both APIs free of charge. Lastly, the Gateway API allows any
              business, app or website to send verification codes through Telegram instead of traditional SMS.
            </p>
            <p className="text-muted-foreground mt-4">
              You can also add{" "}
              <Link href="#" className="text-primary hover:underline">
                Telegram Widgets
              </Link>{" "}
              to your website.
            </p>
            <p className="text-muted-foreground mt-2">
              Designers are welcome to create{" "}
              <Link href="#" className="text-primary hover:underline">
                Animated Stickers and Emoji
              </Link>{" "}
              or{" "}
              <Link href="#" className="text-primary hover:underline">
                Custom Themes
              </Link>{" "}
              for Telegram.
            </p>
          </div>

          {/* Main API Sections */}
          <div className="space-y-8 mb-16">
            {apiSections.map((section) => (
              <div key={section.id} id={section.id} className="bg-card border border-border rounded-xl p-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center flex-shrink-0">
                    <section.icon className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <h2 className="text-xl font-semibold text-foreground mb-2">{section.title}</h2>
                    <p className="text-muted-foreground mb-3">{section.description}</p>
                    <p className="text-muted-foreground mb-3">{section.details}</p>
                    {section.link && (
                      <Link href={section.link.url} className="text-primary hover:underline">
                        {section.link.text} »
                      </Link>
                    )}
                    {section.extra && <p className="text-muted-foreground mt-3">{section.extra}</p>}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Telegram API Documentation */}
          <div className="mb-16">
            <h2 className="text-2xl font-bold text-foreground mb-8 flex items-center gap-3">
              <Settings className="w-6 h-6 text-primary" />
              Getting Started
            </h2>
            <div className="grid gap-3">
              {gettingStartedItems.map((item, index) => (
                <Link
                  key={index}
                  href="#"
                  className="group block p-4 bg-card border border-border rounded-lg hover:border-primary/30 transition-colors"
                >
                  <h3 className="font-medium text-foreground group-hover:text-primary transition-colors">
                    {item.title}
                  </h3>
                  <p className="text-sm text-muted-foreground mt-1">{item.desc}</p>
                </Link>
              ))}
            </div>
          </div>

          {/* Security */}
          <div className="mb-16">
            <h2 className="text-2xl font-bold text-foreground mb-8 flex items-center gap-3">
              <Shield className="w-6 h-6 text-primary" />
              Security
            </h2>
            <div className="grid gap-3">
              {securityItems.map((item, index) => (
                <Link
                  key={index}
                  href="#"
                  className="group block p-4 bg-card border border-border rounded-lg hover:border-primary/30 transition-colors"
                >
                  <h3 className="font-medium text-foreground group-hover:text-primary transition-colors">
                    {item.title}
                  </h3>
                  <p className="text-sm text-muted-foreground mt-1">{item.desc}</p>
                </Link>
              ))}
            </div>
          </div>

          {/* Optimization */}
          <div className="mb-16">
            <h2 className="text-2xl font-bold text-foreground mb-8 flex items-center gap-3">
              <Zap className="w-6 h-6 text-primary" />
              Optimization
            </h2>
            <Link
              href="#"
              className="group block p-4 bg-card border border-border rounded-lg hover:border-primary/30 transition-colors"
            >
              <h3 className="font-medium text-foreground group-hover:text-primary transition-colors">
                Client optimization
              </h3>
              <p className="text-sm text-muted-foreground mt-1">Ways to boost API interactions.</p>
            </Link>
          </div>

          {/* API Methods */}
          <div className="mb-16">
            <h2 className="text-2xl font-bold text-foreground mb-8 flex items-center gap-3">
              <FileText className="w-6 h-6 text-primary" />
              API Methods
            </h2>
            <div className="grid gap-3">
              {apiMethodItems.map((item, index) => (
                <Link
                  key={index}
                  href="#"
                  className="group block p-4 bg-card border border-border rounded-lg hover:border-primary/30 transition-colors"
                >
                  <h3 className="font-medium text-foreground group-hover:text-primary transition-colors">
                    {item.title}
                  </h3>
                  <p className="text-sm text-muted-foreground mt-1">{item.desc}</p>
                </Link>
              ))}
            </div>
          </div>

          {/* Bot Features */}
          <div className="mb-16">
            <h2 className="text-2xl font-bold text-foreground mb-8 flex items-center gap-3">
              <Bot className="w-6 h-6 text-primary" />
              Working with Bots
            </h2>
            <div className="grid gap-3">
              {botFeatures.map((item, index) => (
                <Link
                  key={index}
                  href="#"
                  className="group block p-4 bg-card border border-border rounded-lg hover:border-primary/30 transition-colors"
                >
                  <h3 className="font-medium text-foreground group-hover:text-primary transition-colors">
                    {item.title}
                  </h3>
                  <p className="text-sm text-muted-foreground mt-1">{item.desc}</p>
                </Link>
              ))}
            </div>
          </div>

          {/* Content Features */}
          <div className="mb-16">
            <h2 className="text-2xl font-bold text-foreground mb-8 flex items-center gap-3">
              <Palette className="w-6 h-6 text-primary" />
              Content & Media
            </h2>
            <div className="grid gap-3">
              {contentFeatures.map((item, index) => (
                <Link
                  key={index}
                  href="#"
                  className="group block p-4 bg-card border border-border rounded-lg hover:border-primary/30 transition-colors"
                >
                  <h3 className="font-medium text-foreground group-hover:text-primary transition-colors">
                    {item.title}
                  </h3>
                  <p className="text-sm text-muted-foreground mt-1">{item.desc}</p>
                </Link>
              ))}
            </div>
          </div>

          {/* Group Features */}
          <div className="mb-16">
            <h2 className="text-2xl font-bold text-foreground mb-8 flex items-center gap-3">
              <Users className="w-6 h-6 text-primary" />
              Groups & Channels
            </h2>
            <div className="grid gap-3">
              {groupFeatures.map((item, index) => (
                <Link
                  key={index}
                  href="#"
                  className="group block p-4 bg-card border border-border rounded-lg hover:border-primary/30 transition-colors"
                >
                  <h3 className="font-medium text-foreground group-hover:text-primary transition-colors">
                    {item.title}
                  </h3>
                  <p className="text-sm text-muted-foreground mt-1">{item.desc}</p>
                </Link>
              ))}
            </div>
          </div>

          {/* Monetization */}
          <div className="mb-16">
            <h2 className="text-2xl font-bold text-foreground mb-8 flex items-center gap-3">
              <Star className="w-6 h-6 text-primary" />
              Monetization
            </h2>
            <div className="grid gap-3">
              {monetizationFeatures.map((item, index) => (
                <Link
                  key={index}
                  href="#"
                  className="group block p-4 bg-card border border-border rounded-lg hover:border-primary/30 transition-colors"
                >
                  <h3 className="font-medium text-foreground group-hover:text-primary transition-colors">
                    {item.title}
                  </h3>
                  <p className="text-sm text-muted-foreground mt-1">{item.desc}</p>
                </Link>
              ))}
            </div>
          </div>

          {/* Premium Features */}
          <div className="mb-16">
            <h2 className="text-2xl font-bold text-foreground mb-8 flex items-center gap-3">
              <Gift className="w-6 h-6 text-primary" />
              Premium & Business
            </h2>
            <div className="grid gap-3">
              {premiumFeatures.map((item, index) => (
                <Link
                  key={index}
                  href="#"
                  className="group block p-4 bg-card border border-border rounded-lg hover:border-primary/30 transition-colors"
                >
                  <h3 className="font-medium text-foreground group-hover:text-primary transition-colors">
                    {item.title}
                  </h3>
                  <p className="text-sm text-muted-foreground mt-1">{item.desc}</p>
                </Link>
              ))}
            </div>
          </div>

          {/* Other Features */}
          <div>
            <h2 className="text-2xl font-bold text-foreground mb-8 flex items-center gap-3">
              <Bookmark className="w-6 h-6 text-primary" />
              Other Articles
            </h2>
            <div className="grid gap-3">
              {otherFeatures.map((item, index) => (
                <Link
                  key={index}
                  href="#"
                  className="group block p-4 bg-card border border-border rounded-lg hover:border-primary/30 transition-colors"
                >
                  <h3 className="font-medium text-foreground group-hover:text-primary transition-colors">
                    {item.title}
                  </h3>
                  <p className="text-sm text-muted-foreground mt-1">{item.desc}</p>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </div>

      <TelegramFooter />
    </main>
  )
}
