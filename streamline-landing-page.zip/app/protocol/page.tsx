import Link from "next/link"
import { ExternalLink, Shield, Zap, Code, Bot, MessageSquare, Users, Globe, Star } from "lucide-react"
import TelegramNavbar from "@/components/telegram/navbar"
import TelegramFooter from "@/components/telegram/footer"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Telegram Protocol & API Documentation | MTProto Protocol",
  description:
    "Learn about Telegram's MTProto protocol, security features, and API implementation. Complete documentation for building secure Telegram clients and bots.",
  keywords:
    "telegram protocol, mtproto, telegram security, encryption, api documentation, telegram client, end-to-end encryption",
}

export default function ProtocolPage() {
  return (
    <div className="min-h-screen bg-background">
      <TelegramNavbar />

      <main className="pt-24 pb-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6">
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4">Telegram APIs</h1>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              We offer three kinds of APIs for developers. The Bot API allows you to easily create programs that use
              Telegram messages for an interface. The Telegram API and TDLib allow you to build your own customized
              Telegram clients. You are welcome to use both APIs free of charge.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-6 mb-16">
            {/* Bot API */}
            <div className="bg-card border border-border rounded-lg p-6 hover:border-primary/50 transition-colors">
              <div className="flex items-start gap-4 mb-4">
                <div className="p-3 bg-primary/10 rounded-lg">
                  <Bot className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-foreground mb-2">Bot API</h2>
                  <p className="text-muted-foreground">
                    This API allows you to connect bots to our system. Telegram Bots are special accounts that do not
                    require an additional phone number to set up.
                  </p>
                </div>
              </div>
              <p className="text-muted-foreground mb-4">
                To use this, you don't need to know anything about how our MTProto encryption protocol works — our
                intermediary server will handle all encryption and communication with the Telegram API for you.
              </p>
              <Link href="#" className="inline-flex items-center gap-2 text-primary hover:text-primary/80 font-medium">
                Learn more about the Bot API <ExternalLink className="w-4 h-4" />
              </Link>
            </div>

            {/* TDLib */}
            <div className="bg-card border border-border rounded-lg p-6 hover:border-primary/50 transition-colors">
              <div className="flex items-start gap-4 mb-4">
                <div className="p-3 bg-primary/10 rounded-lg">
                  <Code className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-foreground mb-2">TDLib</h2>
                  <p className="text-muted-foreground">
                    Build your own Telegram apps with our Telegram Database Library - a tool for third-party developers
                    that makes it easy to build fast, secure and feature-rich Telegram apps.
                  </p>
                </div>
              </div>
              <p className="text-muted-foreground mb-4">
                TDLib takes care of all network implementation details, encryption and local data storage. It's open
                source and compatible with virtually any programming language.
              </p>
              <Link href="#" className="inline-flex items-center gap-2 text-primary hover:text-primary/80 font-medium">
                Learn more about TDLib <ExternalLink className="w-4 h-4" />
              </Link>
            </div>

            {/* Gateway API */}
            <div className="bg-card border border-border rounded-lg p-6 hover:border-primary/50 transition-colors">
              <div className="flex items-start gap-4 mb-4">
                <div className="p-3 bg-primary/10 rounded-lg">
                  <MessageSquare className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-foreground mb-2">Gateway API</h2>
                  <p className="text-muted-foreground">
                    Send verification codes through Telegram instead of traditional SMS – lower costs while increasing
                    security and delivery speed.
                  </p>
                </div>
              </div>
              <p className="text-muted-foreground mb-4">
                Users instantly receive messages with codes in a special chat inside Telegram. Telegram's Gateway API is
                completely free to test.
              </p>
              <Link href="#" className="inline-flex items-center gap-2 text-primary hover:text-primary/80 font-medium">
                Learn more about Gateway API <ExternalLink className="w-4 h-4" />
              </Link>
            </div>

            {/* Telegram API */}
            <div className="bg-card border border-border rounded-lg p-6 hover:border-primary/50 transition-colors">
              <div className="flex items-start gap-4 mb-4">
                <div className="p-3 bg-primary/10 rounded-lg">
                  <Globe className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-foreground mb-2">Telegram API</h2>
                  <p className="text-muted-foreground">
                    Build your own customized Telegram clients. It is 100% open for all developers who wish to create
                    Telegram applications on our platform.
                  </p>
                </div>
              </div>
              <p className="text-muted-foreground mb-4">
                Feel free to study the open source code of existing Telegram applications for examples. Don't forget to
                register your application in our system.
              </p>
              <Link href="#" className="inline-flex items-center gap-2 text-primary hover:text-primary/80 font-medium">
                Learn more about Telegram API <ExternalLink className="w-4 h-4" />
              </Link>
            </div>
          </div>

          <div className="space-y-12">
            {/* Getting Started */}
            <section>
              <h2 className="text-3xl font-bold text-foreground mb-6 flex items-center gap-3">
                <Zap className="w-8 h-8 text-primary" />
                Getting Started
              </h2>
              <div className="grid md:grid-cols-2 gap-4">
                <Link
                  href="#"
                  className="p-4 bg-card border border-border rounded-lg hover:border-primary/50 transition-colors"
                >
                  <h3 className="font-semibold text-foreground mb-2">Creating an application</h3>
                  <p className="text-sm text-muted-foreground">
                    How to get your application identifier and create a new Telegram app.
                  </p>
                </Link>
                <Link
                  href="#"
                  className="p-4 bg-card border border-border rounded-lg hover:border-primary/50 transition-colors"
                >
                  <h3 className="font-semibold text-foreground mb-2">User authorization</h3>
                  <p className="text-sm text-muted-foreground">
                    How to register a user's phone to start using the API.
                  </p>
                </Link>
                <Link
                  href="#"
                  className="p-4 bg-card border border-border rounded-lg hover:border-primary/50 transition-colors"
                >
                  <h3 className="font-semibold text-foreground mb-2">Two-factor authentication</h3>
                  <p className="text-sm text-muted-foreground">
                    How to login if 2FA is enabled, how to change password.
                  </p>
                </Link>
                <Link
                  href="#"
                  className="p-4 bg-card border border-border rounded-lg hover:border-primary/50 transition-colors"
                >
                  <h3 className="font-semibold text-foreground mb-2">QR code login</h3>
                  <p className="text-sm text-muted-foreground">QR code login flow for quick authentication.</p>
                </Link>
                <Link
                  href="#"
                  className="p-4 bg-card border border-border rounded-lg hover:border-primary/50 transition-colors"
                >
                  <h3 className="font-semibold text-foreground mb-2">Error handling</h3>
                  <p className="text-sm text-muted-foreground">How to handle API return errors correctly.</p>
                </Link>
                <Link
                  href="#"
                  className="p-4 bg-card border border-border rounded-lg hover:border-primary/50 transition-colors"
                >
                  <h3 className="font-semibold text-foreground mb-2">Handling updates</h3>
                  <p className="text-sm text-muted-foreground">How to subscribe to updates and handle them properly.</p>
                </Link>
              </div>
            </section>

            {/* Security */}
            <section>
              <h2 className="text-3xl font-bold text-foreground mb-6 flex items-center gap-3">
                <Shield className="w-8 h-8 text-primary" />
                Security
              </h2>
              <div className="grid md:grid-cols-2 gap-4">
                <Link
                  href="#"
                  className="p-4 bg-card border border-border rounded-lg hover:border-primary/50 transition-colors"
                >
                  <h3 className="font-semibold text-foreground mb-2">Secret chats, end-to-end encryption</h3>
                  <p className="text-sm text-muted-foreground">End-to-end-encrypted messaging implementation.</p>
                </Link>
                <Link
                  href="#"
                  className="p-4 bg-card border border-border rounded-lg hover:border-primary/50 transition-colors"
                >
                  <h3 className="font-semibold text-foreground mb-2">Security guidelines</h3>
                  <p className="text-sm text-muted-foreground">Important checks required in your client application.</p>
                </Link>
                <Link
                  href="#"
                  className="p-4 bg-card border border-border rounded-lg hover:border-primary/50 transition-colors"
                >
                  <h3 className="font-semibold text-foreground mb-2">Perfect Forward Secrecy</h3>
                  <p className="text-sm text-muted-foreground">
                    Binding temporary authorization key to permanent ones.
                  </p>
                </Link>
                <Link
                  href="#"
                  className="p-4 bg-card border border-border rounded-lg hover:border-primary/50 transition-colors"
                >
                  <h3 className="font-semibold text-foreground mb-2">Voice and Video Calls</h3>
                  <p className="text-sm text-muted-foreground">End-to-end-encrypted calls implementation.</p>
                </Link>
              </div>
            </section>

            {/* Working with Bots */}
            <section>
              <h2 className="text-3xl font-bold text-foreground mb-6 flex items-center gap-3">
                <Bot className="w-8 h-8 text-primary" />
                Working with Bots
              </h2>
              <div className="grid md:grid-cols-2 gap-4">
                <Link
                  href="#"
                  className="p-4 bg-card border border-border rounded-lg hover:border-primary/50 transition-colors"
                >
                  <h3 className="font-semibold text-foreground mb-2">Using MTProto API</h3>
                  <p className="text-sm text-muted-foreground">How to work with bots using the MTProto API.</p>
                </Link>
                <Link
                  href="#"
                  className="p-4 bg-card border border-border rounded-lg hover:border-primary/50 transition-colors"
                >
                  <h3 className="font-semibold text-foreground mb-2">Commands</h3>
                  <p className="text-sm text-muted-foreground">
                    Bots offer commands that can be used by users in private or chat.
                  </p>
                </Link>
                <Link
                  href="#"
                  className="p-4 bg-card border border-border rounded-lg hover:border-primary/50 transition-colors"
                >
                  <h3 className="font-semibold text-foreground mb-2">Buttons</h3>
                  <p className="text-sm text-muted-foreground">
                    Users can interact via buttons or inline buttons from any chat.
                  </p>
                </Link>
                <Link
                  href="#"
                  className="p-4 bg-card border border-border rounded-lg hover:border-primary/50 transition-colors"
                >
                  <h3 className="font-semibold text-foreground mb-2">Inline queries</h3>
                  <p className="text-sm text-muted-foreground">
                    Users can interact via inline queries from the text input field.
                  </p>
                </Link>
                <Link
                  href="#"
                  className="p-4 bg-card border border-border rounded-lg hover:border-primary/50 transition-colors"
                >
                  <h3 className="font-semibold text-foreground mb-2">Games</h3>
                  <p className="text-sm text-muted-foreground">
                    Bots can offer users HTML5 games to play solo or compete.
                  </p>
                </Link>
                <Link
                  href="#"
                  className="p-4 bg-card border border-border rounded-lg hover:border-primary/50 transition-colors"
                >
                  <h3 className="font-semibold text-foreground mb-2">Mini apps</h3>
                  <p className="text-sm text-muted-foreground">
                    Bots can offer interactive HTML5 mini apps to replace any website.
                  </p>
                </Link>
              </div>
            </section>

            {/* Groups & Channels */}
            <section>
              <h2 className="text-3xl font-bold text-foreground mb-6 flex items-center gap-3">
                <Users className="w-8 h-8 text-primary" />
                Groups & Channels
              </h2>
              <div className="grid md:grid-cols-2 gap-4">
                <Link
                  href="#"
                  className="p-4 bg-card border border-border rounded-lg hover:border-primary/50 transition-colors"
                >
                  <h3 className="font-semibold text-foreground mb-2">Channels, supergroups, gigagroups</h3>
                  <p className="text-sm text-muted-foreground">Understanding the differences between group types.</p>
                </Link>
                <Link
                  href="#"
                  className="p-4 bg-card border border-border rounded-lg hover:border-primary/50 transition-colors"
                >
                  <h3 className="font-semibold text-foreground mb-2">Forums</h3>
                  <p className="text-sm text-muted-foreground">Creating forums with multiple distinct topics.</p>
                </Link>
                <Link
                  href="#"
                  className="p-4 bg-card border border-border rounded-lg hover:border-primary/50 transition-colors"
                >
                  <h3 className="font-semibold text-foreground mb-2">Channel statistics</h3>
                  <p className="text-sm text-muted-foreground">
                    Detailed channel statistics for channels and supergroups.
                  </p>
                </Link>
                <Link
                  href="#"
                  className="p-4 bg-card border border-border rounded-lg hover:border-primary/50 transition-colors"
                >
                  <h3 className="font-semibold text-foreground mb-2">Discussion groups</h3>
                  <p className="text-sm text-muted-foreground">Associate groups with channels for post discussions.</p>
                </Link>
                <Link
                  href="#"
                  className="p-4 bg-card border border-border rounded-lg hover:border-primary/50 transition-colors"
                >
                  <h3 className="font-semibold text-foreground mb-2">Invite links and join requests</h3>
                  <p className="text-sm text-muted-foreground">
                    Public usernames and private invite links with join requests.
                  </p>
                </Link>
                <Link
                  href="#"
                  className="p-4 bg-card border border-border rounded-lg hover:border-primary/50 transition-colors"
                >
                  <h3 className="font-semibold text-foreground mb-2">Admin rights and permissions</h3>
                  <p className="text-sm text-muted-foreground">Handle admin permissions and granular bans.</p>
                </Link>
              </div>
            </section>

            {/* Premium & Monetization */}
            <section>
              <h2 className="text-3xl font-bold text-foreground mb-6 flex items-center gap-3">
                <Star className="w-8 h-8 text-primary" />
                Premium & Monetization
              </h2>
              <div className="grid md:grid-cols-2 gap-4">
                <Link
                  href="#"
                  className="p-4 bg-card border border-border rounded-lg hover:border-primary/50 transition-colors"
                >
                  <h3 className="font-semibold text-foreground mb-2">Telegram Premium</h3>
                  <p className="text-sm text-muted-foreground">
                    Optional subscription service with additional features.
                  </p>
                </Link>
                <Link
                  href="#"
                  className="p-4 bg-card border border-border rounded-lg hover:border-primary/50 transition-colors"
                >
                  <h3 className="font-semibold text-foreground mb-2">Telegram Business</h3>
                  <p className="text-sm text-muted-foreground">
                    Business features like opening hours, quick replies, and more.
                  </p>
                </Link>
                <Link
                  href="#"
                  className="p-4 bg-card border border-border rounded-lg hover:border-primary/50 transition-colors"
                >
                  <h3 className="font-semibold text-foreground mb-2">Telegram Stars</h3>
                  <p className="text-sm text-muted-foreground">
                    Virtual items for purchasing digital goods and services.
                  </p>
                </Link>
                <Link
                  href="#"
                  className="p-4 bg-card border border-border rounded-lg hover:border-primary/50 transition-colors"
                >
                  <h3 className="font-semibold text-foreground mb-2">Subscriptions</h3>
                  <p className="text-sm text-muted-foreground">Create subscriptions charging users Telegram Stars.</p>
                </Link>
                <Link
                  href="#"
                  className="p-4 bg-card border border-border rounded-lg hover:border-primary/50 transition-colors"
                >
                  <h3 className="font-semibold text-foreground mb-2">Channel boosts</h3>
                  <p className="text-sm text-muted-foreground">Premium users can grant channels additional features.</p>
                </Link>
                <Link
                  href="#"
                  className="p-4 bg-card border border-border rounded-lg hover:border-primary/50 transition-colors"
                >
                  <h3 className="font-semibold text-foreground mb-2">Giveaways & gifts</h3>
                  <p className="text-sm text-muted-foreground">Distribute Premium subscriptions among followers.</p>
                </Link>
              </div>
            </section>

            {/* Additional Resources */}
            <section className="bg-card border border-border rounded-lg p-8">
              <h2 className="text-2xl font-bold text-foreground mb-4">Additional Resources</h2>
              <div className="space-y-3">
                <Link
                  href="#"
                  className="flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors"
                >
                  <ExternalLink className="w-4 h-4" />
                  <span>Telegram Widgets for websites</span>
                </Link>
                <Link
                  href="#"
                  className="flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors"
                >
                  <ExternalLink className="w-4 h-4" />
                  <span>Create Animated Stickers and Emoji</span>
                </Link>
                <Link
                  href="#"
                  className="flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors"
                >
                  <ExternalLink className="w-4 h-4" />
                  <span>Create Custom Themes for Telegram</span>
                </Link>
                <Link
                  href="#"
                  className="flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors"
                >
                  <ExternalLink className="w-4 h-4" />
                  <span>API TL-schema documentation</span>
                </Link>
                <Link
                  href="#"
                  className="flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors"
                >
                  <ExternalLink className="w-4 h-4" />
                  <span>Layer changelog</span>
                </Link>
              </div>
            </section>
          </div>
        </div>
      </main>

      <TelegramFooter />
    </div>
  )
}
