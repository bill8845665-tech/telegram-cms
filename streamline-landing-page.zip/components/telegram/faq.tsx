"use client"

import { useState } from "react"
import {
  ChevronDown,
  ChevronRight,
  Search,
  Shield,
  MessageCircle,
  Users,
  AtSign,
  Lock,
  User,
  Bot,
  HelpCircle,
} from "lucide-react"

const faqCategories = [
  {
    id: "general",
    title: "General Questions",
    icon: HelpCircle,
    questions: [
      {
        q: "What is Telegram? What do I do here?",
        a: "Telegram is a messaging app with a focus on speed and security, it's super-fast, simple and free. You can use Telegram on all your devices at the same time — your messages sync seamlessly across any number of your phones, tablets or computers. Telegram is one of the top 5 most downloaded apps in the world with over 1 billion active users.\n\nWith Telegram, you can send messages, photos, videos and files of any type (doc, zip, mp3, etc), as well as create groups for up to 200,000 people or channels for broadcasting to unlimited audiences.",
      },
      {
        q: "Who is Telegram for?",
        a: "Telegram is for everyone who wants fast and reliable messaging and calls. Business users and small teams may like the large groups, usernames, desktop apps and powerful file sharing options.\n\nSince Telegram groups can have up to 200,000 members, we support replies, mentions and hashtags that help maintain order and keep communication in large communities efficient.",
      },
      {
        q: "How is Telegram different from WhatsApp?",
        a: "Unlike WhatsApp, Telegram is a cloud-based messenger with seamless sync. As a result, you can access your messages from several devices at once, including tablets and computers, and share an unlimited number of photos, videos and files (doc, zip, mp3, etc.) of up to 2 GB each.\n\nTelegram needs less than 100 MB on your device — you can keep all your media in the cloud without deleting things. Thanks to Telegram's multi-data center infrastructure and encryption, it is faster and way more secure.",
      },
      {
        q: "How old is Telegram?",
        a: "Telegram for iOS was launched on August 14, 2013. The alpha version of Telegram for Android officially launched on October 20, 2013. More and more Telegram clients appear, built by independent developers using Telegram's open platform.",
      },
      {
        q: "Which devices can I use?",
        a: "You can use Telegram on smartphones, tablets, and even computers. We have apps for iOS (11.0 and above), Android (6.0 and up), a native macOS app and a universal desktop app for Windows, macOS, and Linux. Telegram Web can also help to quickly do something on the go.\n\nYou can log in to Telegram from as many of your devices as you like — all at the same time.",
      },
      {
        q: "Who are the people behind Telegram?",
        a: "Telegram is supported by Pavel Durov and his brother Nikolai. Pavel supports Telegram financially and ideologically while Nikolai's input is technological. To make Telegram possible, Nikolai developed a unique custom data protocol, which is open, secure and optimized for work with multiple data-centers.",
      },
      {
        q: "Where is Telegram based?",
        a: "The Telegram development team is based in Dubai. Most of the developers behind Telegram originally come from St. Petersburg, the city famous for its unprecedented number of highly skilled engineers.",
      },
      {
        q: "How are you going to make money out of this?",
        a: "We believe in fast and secure messaging that is also 100% free. Telegram has implemented sustainable forms of monetization that prioritize its users:\n\n• In 2021, Telegram launched Sponsored Messages – minimalist, privacy-conscious advertisements.\n• In 2022, Telegram launched a Premium subscription which users can purchase to support the app and unlock additional exclusive features.",
      },
    ],
  },
  {
    id: "basics",
    title: "Telegram Basics",
    icon: MessageCircle,
    questions: [
      {
        q: "Who can I write to?",
        a: "You can write to people who are in your phone contacts and have Telegram. Another way of contacting people is to type their Telegram username into the search field — you don't need to know their phone number to do this.",
      },
      {
        q: "Who can contact me?",
        a: "People can contact you on Telegram if they know your phone number or if you message them first. If they don't know your phone number, they can find you when you both are members of the same group, or if you set a public username.",
      },
      {
        q: "What do the check marks mean?",
        a: "One check — message delivered to the Telegram cloud and your friend has been notified if he allows notifications.\n\nTwo checks — message read (your friend opened Telegram and opened the conversation with the message).",
      },
      {
        q: "Can I hide my 'last seen' time?",
        a: "You can choose who sees this info in Privacy and Security settings. Remember that you won't see Last Seen timestamps for people with whom you don't share your own.\n\nThere are four possible approximate values:\n• Last seen recently — between 1 second and 2-3 days\n• Last seen within a week — between 2-3 and seven days\n• Last seen within a month — between 6-7 days and a month\n• Last seen a long time ago — more than a month",
      },
      {
        q: "Can I delete my messages?",
        a: "Yes. You can always delete any messages you sent or received for both sides in any one-on-one conversation (in groups, it's still your own messages only). You can also clear the entire chat history on both ends. On Telegram, deleted messages do not leave a mark in the chat.",
      },
      {
        q: "Can I make calls via Telegram?",
        a: "Yes! You can make end-to-end encrypted Voice Calls and Video Calls. If you want more participants, try starting a Voice Chat in one of the groups you created. Voice Chats add a live layer of ephemeral talk to the group.",
      },
    ],
  },
  {
    id: "groups",
    title: "Groups and Channels",
    icon: Users,
    questions: [
      {
        q: "What makes Telegram groups cool?",
        a: "Telegram groups can have up to 200,000 members each and are extremely powerful communication tools. Key features include:\n\n• Unified history — Edit your messages after posting, delete them so that they disappear for everyone.\n• Cross-platform availability — Access your messages anytime, from any number of devices.\n• Instant search — Find the message you're looking for, even among millions.\n• Replies, mentions, hashtags — Easily trace a conversation.\n• Smart notifications — Mute the group to get notifications only when mentioned.\n• Pinned messages — Pin any message to be displayed at the top.",
      },
      {
        q: "What's the difference between groups and channels?",
        a: "Telegram groups are ideal for sharing stuff with friends and family or collaboration in small teams. Groups can have up to 200,000 members.\n\nChannels are a tool for broadcasting messages to large audiences. A channel can have an unlimited number of subscribers. When you post in a channel, the message is signed with the channel's name and photo.",
      },
      {
        q: "How do I create a group?",
        a: "iOS: Start a new message (tap the icon in the top right corner in Chats) > 'New Group'.\n\nAndroid: Tap the circular pencil icon in the chat list > 'New Group'.\n\nTelegram Desktop: Click the menu button in the top left corner > 'New Group'.",
      },
      {
        q: "How do I add more members? What's an invite link?",
        a: "You can add your contacts, or using search by username. It is easy to migrate existing groups to Telegram by sending people an invite link. To create an invite link, go to Group Info > Add Member > Invite to Group via Link.\n\nAnyone who has Telegram installed will be able to join your group by following this link.",
      },
    ],
  },
  {
    id: "usernames",
    title: "Usernames and t.me",
    icon: AtSign,
    questions: [
      {
        q: "What are usernames? How do I get one?",
        a: "You can set a public username on Telegram. It then becomes possible for other users to find you by that username — you will appear in search under 'global results'. You can set up a username in Settings and use the universal search box in the chat list to search for chats, messages, and usernames.",
      },
      {
        q: "How does t.me work?",
        a: "Once you've set a username, you can give people a t.me/username or a username.t.me link. Opening either of those links on their phone will automatically fire up their Telegram app and open a chat with you.\n\nThis way people can contact you on Telegram without knowing your phone number.",
      },
      {
        q: "What can I use as my username?",
        a: "You can use a-z, 0-9 and underscores. Usernames are case-insensitive, but Telegram will store your capitalization preferences (e.g. Telegram and TeleGram is the same user).",
      },
      {
        q: "Do I need a username?",
        a: "You don't have to get one. Remember that Telegram usernames are public and choosing a username on Telegram makes it possible for people to find you in global search and send you messages even if they don't have your number.",
      },
      {
        q: "What do I do if my username is taken?",
        a: "Telegram basic usernames are distributed on a first-come – first-serve basis. If your desired username is already taken and it is not registered as a collectible, we can help you acquire it for your account or channel, provided that you have that same username on at least two of these services: Facebook, Twitter, Instagram.\n\nTo request a username, contact @Username_bot.",
      },
    ],
  },
  {
    id: "security",
    title: "Security",
    icon: Shield,
    questions: [
      {
        q: "How secure is Telegram?",
        a: "Telegram is more secure than mass market messengers like WhatsApp and Line. We are based on the MTProto protocol, built upon time-tested algorithms to make security compatible with high-speed delivery and reliability on weak connections.",
      },
      {
        q: "So how do you encrypt data?",
        a: "We support two layers of secure encryption. Server-client encryption is used in Cloud Chats (private and group chats), Secret Chats use an additional layer of client-client encryption.\n\nOur encryption is based on 256-bit symmetric AES encryption, 2048-bit RSA encryption, and Diffie–Hellman secure key exchange.",
      },
      {
        q: "Why should I trust you?",
        a: "Telegram is open, anyone can check our source code, protocol and API, see how everything works and make an informed decision. Telegram supports verifiable builds, which allow experts to independently verify that our code published on GitHub is the exact same code that is used to build the apps.\n\nOn top of that, Telegram's primary focus is not to bring a profit, so commercial interests will never interfere with our mission.",
      },
      {
        q: "Can Telegram protect me against everything?",
        a: "Telegram can help when it comes to data transfer and secure communication. All data that you send and receive via Telegram cannot be deciphered when intercepted by your internet service provider, owners of Wi-Fi routers you connect to, or other third parties.\n\nBut please remember that we cannot protect you from your own mother if she takes your unlocked phone without a passcode.",
      },
      {
        q: "How does 2-Step Verification work?",
        a: "You can set up an additional password in Settings > Privacy and Security > 2-Step Verification. Once enabled, you will need both an SMS code and a password to log in. You can also set up a recovery email address that will help regain access, should you forget your password.",
      },
    ],
  },
  {
    id: "secret",
    title: "Secret Chats",
    icon: Lock,
    questions: [
      {
        q: "How are secret chats different?",
        a: "Secret chats are meant for people who want more secrecy than the average fella. All messages in secret chats use end-to-end encryption. This means only you and the recipient can read those messages — nobody else can decipher them, including us here at Telegram.\n\nMessages cannot be forwarded from secret chats. And when you delete messages on your side of the conversation, the app on the other side of the secret chat will be ordered to delete them as well.",
      },
      {
        q: "How do I start a secret chat?",
        a: "Open the profile of the user you want to contact. Tap on '…', then 'Start Secret Chat'.\n\nRemember that Telegram secret chats are device-specific. If you start a secret chat with a friend on one of your devices, this chat will only be available on that device.",
      },
      {
        q: "How do self-destructing messages work?",
        a: "The Self-Destruct Timer is available for all messages in Secret Chats and for media in private cloud chats.\n\nTo set the timer, simply tap the clock icon, and then choose the desired time limit. The clock starts ticking the moment the message is displayed on the recipient's screen. As soon as the time runs out, the message disappears from both devices.",
      },
      {
        q: "Why not just make all chats 'secret'?",
        a: "All Telegram messages are always securely encrypted. Messages in Secret Chats use client-client encryption, while Cloud Chats use client-server/server-client encryption and are stored encrypted in the Telegram Cloud.\n\nThis enables your cloud messages to be both secure and immediately accessible from any of your devices — even if you lose your device altogether.",
      },
    ],
  },
  {
    id: "account",
    title: "Your Account",
    icon: User,
    questions: [
      {
        q: "Who can see my phone number?",
        a: "On Telegram, you can send messages in private chats and groups without making your phone number visible. By default, your number is only visible to people who you've added to your address book as contacts. You can further modify this in Settings > Privacy and Security > Phone Number.",
      },
      {
        q: "I have a new phone number, what do I do?",
        a: "Each phone number is a separate account on Telegram. If you will no longer use the old number, simply go to Settings and change the number connected to your Telegram account to the new number.\n\nImportant: make sure you have access to your connected phone number — otherwise you risk losing access to your account.",
      },
      {
        q: "How do I change my phone number?",
        a: "You can change your number in Telegram and keep everything, including all your contacts, messages, and media from the Telegram cloud, as well as all your Secret Chats on all devices.\n\nTo change your number, go to Settings, then tap on your phone number, then 'Change Number'.",
      },
      {
        q: "How do I delete my account?",
        a: "If you would like to delete your account, you can do this on the deactivation page. Deleting your account permanently removes all your messages and contacts. All groups and channels that you've created are orphaned and left without a creator but admins retain their rights.\n\nNote: you'll receive the code via Telegram, not SMS.",
      },
      {
        q: "How does account self-destruction work?",
        a: "Telegram is not a commercial organization, and we value our disk space greatly. If you stop using Telegram and don't come online for at least 18 months, your account will be deleted along with all messages, media, contacts and every other piece of data you store in the Telegram cloud.\n\nYou can change the exact period after which your inactive account will self-destruct in Settings.",
      },
      {
        q: "My phone was stolen, what do I do?",
        a: "If you have access to Telegram on another device:\n1. Go to Telegram Settings > Privacy and Security and turn on Two-Step Verification.\n2. Go to Settings > Devices and terminate your Telegram session on the old device.\n3. Contact your phone provider to block your old SIM and issue a new one.\n\nIf you don't have access to Telegram on any other devices, first contact your phone provider to block your old SIM.",
      },
    ],
  },
  {
    id: "bots",
    title: "Bots",
    icon: Bot,
    questions: [
      {
        q: "What are bots?",
        a: "Bots are like small programs that run right inside Telegram. They are made by third-party developers using the Telegram Bot API.",
      },
      {
        q: "How do I create a bot?",
        a: "Creating Telegram bots is super-easy, but you will need at least some skills in computer programming. If you're sure you're up to it, our Introduction for Developers is a good place to start.\n\nUnfortunately, there are no out-of-the-box ways to create a working bot if you are not a developer.",
      },
      {
        q: "A bot is sending me messages, how do I make it stop?",
        a: "If you don't want a bot to send you messages, feel free to block it — same as you would block a human user. Some Telegram clients have a 'Stop Bot' button right in the bot's profile.\n\nThat said, most bot developers offer commands that silence the bot, check its /help for clues.",
      },
      {
        q: "Are bots safe?",
        a: "Yes. Bots are no different from human users that you meet in groups. They can see your public name, username, and profile pictures, and they can see messages you send to them, that's it. They can't access your last seen status and don't see your phone number.\n\nNaturally, any bot should be treated as a stranger — don't give them your passwords, Telegram codes or bank account numbers.",
      },
      {
        q: "If I add a bot to my group, can it read my messages?",
        a: "Bots can work in two modes when you add them to groups. By default, bots only see messages that are meant for them. In this case, you'll see 'has no access to messages' in the group members list.\n\nSome bots need more information to work, so developers may disable the privacy mode. In this case, the bot will see all messages sent to the group.",
      },
    ],
  },
]

export default function TelegramFAQ() {
  const [searchQuery, setSearchQuery] = useState("")
  const [expandedCategory, setExpandedCategory] = useState<string | null>("general")
  const [expandedQuestions, setExpandedQuestions] = useState<Set<string>>(new Set())

  const toggleCategory = (categoryId: string) => {
    setExpandedCategory(expandedCategory === categoryId ? null : categoryId)
  }

  const toggleQuestion = (questionId: string) => {
    const newExpanded = new Set(expandedQuestions)
    if (newExpanded.has(questionId)) {
      newExpanded.delete(questionId)
    } else {
      newExpanded.add(questionId)
    }
    setExpandedQuestions(newExpanded)
  }

  const filteredCategories = faqCategories
    .map((category) => ({
      ...category,
      questions: category.questions.filter(
        (q) =>
          q.q.toLowerCase().includes(searchQuery.toLowerCase()) ||
          q.a.toLowerCase().includes(searchQuery.toLowerCase()),
      ),
    }))
    .filter((category) => category.questions.length > 0)

  return (
    <section id="faq" className="py-20 bg-background">
      <div className="container mx-auto px-4 max-w-4xl">
        {/* Header */}
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Telegram FAQ</h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            This FAQ provides answers to basic questions about Telegram. Check out our Advanced FAQ for more technical
            information.
          </p>
        </div>

        {/* Search */}
        <div className="relative mb-8">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
          <input
            type="text"
            placeholder="Search questions..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-12 pr-4 py-3 rounded-xl border border-border bg-card text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all"
          />
        </div>

        {/* FAQ Categories */}
        <div className="space-y-4">
          {filteredCategories.map((category) => {
            const IconComponent = category.icon
            const isExpanded = expandedCategory === category.id

            return (
              <div key={category.id} className="bg-card rounded-xl border border-border overflow-hidden">
                {/* Category Header */}
                <button
                  onClick={() => toggleCategory(category.id)}
                  className="w-full flex items-center justify-between p-4 hover:bg-accent/50 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                      <IconComponent className="h-5 w-5 text-primary" />
                    </div>
                    <span className="font-semibold text-foreground">{category.title}</span>
                    <span className="text-sm text-muted-foreground">({category.questions.length})</span>
                  </div>
                  <ChevronDown
                    className={`h-5 w-5 text-muted-foreground transition-transform duration-200 ${
                      isExpanded ? "rotate-180" : ""
                    }`}
                  />
                </button>

                {/* Questions */}
                {isExpanded && (
                  <div className="border-t border-border">
                    {category.questions.map((question, qIndex) => {
                      const questionId = `${category.id}-${qIndex}`
                      const isQuestionExpanded = expandedQuestions.has(questionId)

                      return (
                        <div key={qIndex} className="border-b border-border last:border-b-0">
                          <button
                            onClick={() => toggleQuestion(questionId)}
                            className="w-full flex items-start justify-between p-4 text-left hover:bg-accent/30 transition-colors"
                          >
                            <span className="font-medium text-foreground pr-4">{question.q}</span>
                            <ChevronRight
                              className={`h-5 w-5 text-muted-foreground flex-shrink-0 mt-0.5 transition-transform duration-200 ${
                                isQuestionExpanded ? "rotate-90" : ""
                              }`}
                            />
                          </button>

                          {isQuestionExpanded && (
                            <div className="px-4 pb-4">
                              <div className="bg-accent/30 rounded-lg p-4">
                                <p className="text-muted-foreground whitespace-pre-line leading-relaxed">
                                  {question.a}
                                </p>
                              </div>
                            </div>
                          )}
                        </div>
                      )
                    })}
                  </div>
                )}
              </div>
            )
          })}
        </div>

        {/* No Results */}
        {filteredCategories.length === 0 && (
          <div className="text-center py-12">
            <p className="text-muted-foreground">No questions found matching &quot;{searchQuery}&quot;</p>
          </div>
        )}

        {/* Contact Support */}
        <div className="mt-12 text-center">
          <div className="bg-card rounded-xl border border-border p-8">
            <h3 className="text-xl font-semibold text-foreground mb-2">Still have questions?</h3>
            <p className="text-muted-foreground mb-4">
              If you can&apos;t find the answer you&apos;re looking for, please contact our support team.
            </p>
            <a
              href="https://telegram.org/support"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center px-6 py-3 bg-primary text-primary-foreground rounded-full font-medium hover:bg-primary/90 transition-colors"
            >
              Contact Support
            </a>
          </div>
        </div>
      </div>
    </section>
  )
}
