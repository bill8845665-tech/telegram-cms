"use client"

import Link from "next/link"
import Image from "next/image"
import { motion } from "framer-motion"

const footerLinks = {
  About: [
    { label: "FAQ", href: "/faq" },
    { label: "Blog", href: "https://telegram.org/blog", external: true },
    { label: "Jobs", href: "https://telegram.org/jobs", external: true },
  ],
  Apps: [
    { label: "Mobile Apps", href: "/apps#mobile" },
    { label: "Desktop Apps", href: "/apps#desktop" },
    { label: "Web Apps", href: "/apps#web" },
  ],
  Platform: [
    { label: "API", href: "/api-docs" },
    { label: "Protocol", href: "/protocol" },
    { label: "TDLib", href: "/apps#tdlib" },
  ],
  Resources: [
    { label: "Privacy Policy", href: "https://telegram.org/privacy", external: true },
    { label: "Terms of Service", href: "https://telegram.org/tos", external: true },
    { label: "Bug Bounty", href: "/apps#bug-bounty" },
  ],
}

export default function TelegramFooter() {
  return (
    <footer className="bg-foreground py-16">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="grid grid-cols-1 md:grid-cols-5 gap-10">
          {/* Logo Column */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
          >
            <div className="flex items-center gap-2 mb-4">
              <Image src="/telegram-logo.png" alt="Telegram Logo" width={40} height={40} className="w-10 h-10" />
              <span className="text-xl font-semibold text-background">Telegram</span>
            </div>
            <p className="text-background/60 text-sm leading-relaxed">
              Telegram Messenger LLP
              <br />
              Version 6.4.1
              <br />
              2025 © All rights reserved
            </p>
          </motion.div>

          {/* Link Columns */}
          {Object.entries(footerLinks).map(([title, links], columnIndex) => (
            <motion.div
              key={title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: columnIndex * 0.1 }}
              viewport={{ once: true }}
            >
              <h3 className="font-semibold mb-4 text-background">{title}</h3>
              <ul className="space-y-3">
                {links.map((link) => (
                  <li key={link.label}>
                    <Link
                      href={link.href}
                      className="text-background/60 hover:text-primary transition-colors text-sm"
                      {...(link.external ? { target: "_blank", rel: "noopener noreferrer" } : {})}
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>

        {/* Bottom Bar */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          viewport={{ once: true }}
          className="border-t border-background/10 mt-12 pt-8"
        >
          <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
            <p className="text-background/40 text-sm">
              Built with{" "}
              <Link href="https://telegram.org" className="hover:text-primary transition-colors">
                Telegram
              </Link>{" "}
              - The world's fastest messaging app
            </p>
            <div className="flex gap-6 text-sm">
              <Link
                href="https://telegram.org/privacy"
                className="text-background/40 hover:text-background transition-colors"
                target="_blank"
                rel="noopener noreferrer"
              >
                Privacy
              </Link>
              <Link
                href="https://telegram.org/tos"
                className="text-background/40 hover:text-background transition-colors"
                target="_blank"
                rel="noopener noreferrer"
              >
                Terms
              </Link>
              <Link href="/faq" className="text-background/40 hover:text-background transition-colors">
                Help
              </Link>
            </div>
          </div>
        </motion.div>
      </div>
    </footer>
  )
}
