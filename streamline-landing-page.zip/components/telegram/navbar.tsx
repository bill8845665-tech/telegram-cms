"use client"

import Link from "next/link"
import { useState } from "react"
import { Menu, X } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function TelegramNavbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between h-16">
          <nav className="hidden md:flex items-center gap-8">
            <Link href="/" className="text-sm text-muted-foreground hover:text-primary transition-colors">
              Home
            </Link>
            <Link href="/apps" className="text-sm text-muted-foreground hover:text-primary transition-colors">
              Apps
            </Link>
            <Link href="/faq" className="text-sm text-muted-foreground hover:text-primary transition-colors">
              FAQ
            </Link>
            <Link href="/api-docs" className="text-sm text-muted-foreground hover:text-primary transition-colors">
              API
            </Link>
            <Link href="/protocol" className="text-sm text-muted-foreground hover:text-primary transition-colors">
              Protocol
            </Link>
          </nav>

          {/* Mobile Menu Button - now on the left */}
          <button className="md:hidden p-2" onClick={() => setIsMenuOpen(!isMenuOpen)} aria-label="Toggle menu">
            {isMenuOpen ? <X className="w-6 h-6 text-foreground" /> : <Menu className="w-6 h-6 text-foreground" />}
          </button>

          {/* Version Badge and CTA - stays on the right */}
          <div className="flex items-center gap-3">
            <span className="text-xs text-muted-foreground bg-secondary px-2 py-1 rounded">v6.4.1</span>
            <Button className="bg-primary hover:bg-primary/90 text-primary-foreground rounded-full px-6">
              Get Telegram
            </Button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden py-4 border-t border-border">
            <nav className="flex flex-col gap-4">
              <Link href="/" className="text-sm text-muted-foreground hover:text-primary">
                Home
              </Link>
              <Link href="/apps" className="text-sm text-muted-foreground hover:text-primary">
                Apps
              </Link>
              <Link href="/faq" className="text-sm text-muted-foreground hover:text-primary">
                FAQ
              </Link>
              <Link href="/api-docs" className="text-sm text-muted-foreground hover:text-primary">
                API
              </Link>
              <Link href="/protocol" className="text-sm text-muted-foreground hover:text-primary">
                Protocol
              </Link>
              <Button className="bg-primary hover:bg-primary/90 text-primary-foreground rounded-full w-full mt-2">
                Get Telegram
              </Button>
            </nav>
          </div>
        )}
      </div>
    </header>
  )
}
