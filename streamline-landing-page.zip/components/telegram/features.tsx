"use client"

import { motion } from "framer-motion"
import { Shield, Zap, Cloud, Users, Lock, Smile } from "lucide-react"

const features = [
  {
    icon: Shield,
    title: "Secure",
    description: "Telegram keeps your messages safe from hacker attacks with MTProto protocol.",
  },
  {
    icon: Zap,
    title: "Fast",
    description: "Telegram is the fastest messaging app on the market, connecting people via unique data centers.",
  },
  {
    icon: Cloud,
    title: "Cloud-Based",
    description: "Access your messages from any of your phones, tablets or computers. Unlimited cloud storage.",
  },
  {
    icon: Users,
    title: "Group Chat",
    description: "Create groups of up to 200,000 members, share large files, and manage with powerful admin tools.",
  },
  {
    icon: Lock,
    title: "Private",
    description: "Secret chats use end-to-end encryption, leave no trace on servers, and support self-destruct timers.",
  },
  {
    icon: Smile,
    title: "Fun",
    description: "Express yourself with custom stickers, animated emoji, themes, and thousands of bots.",
  },
]

export default function TelegramFeatures() {
  return (
    <section className="py-20 bg-background">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">Why Telegram?</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Simple, fast, secure messaging that works across all your devices.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="bg-card border border-border rounded-2xl p-6 hover:shadow-lg hover:shadow-primary/10 transition-shadow group"
            >
              <div className="w-14 h-14 bg-primary/10 rounded-2xl flex items-center justify-center mb-5 group-hover:bg-primary transition-colors">
                <feature.icon className="w-7 h-7 text-primary group-hover:text-primary-foreground transition-colors" />
              </div>
              <h3 className="text-xl font-semibold text-foreground mb-3">{feature.title}</h3>
              <p className="text-muted-foreground leading-relaxed">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
