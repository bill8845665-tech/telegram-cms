"use client"

import { motion } from "framer-motion"
import { Apple, Monitor, Smartphone } from "lucide-react"

const platforms = [
  {
    icon: Smartphone,
    name: "iPhone/iPad",
    subtitle: "iOS 12.0 or later",
    colorClass: "bg-platform-ios",
  },
  {
    icon: () => (
      <svg className="w-8 h-8" viewBox="0 0 24 24" fill="currentColor">
        <path d="M17.523 2H6.477C4.005 2 2 4.005 2 6.477v11.046C2 19.995 4.005 22 6.477 22h11.046C19.995 22 22 19.995 22 17.523V6.477C22 4.005 19.995 2 17.523 2zM12 17.5c-3.033 0-5.5-2.467-5.5-5.5S8.967 6.5 12 6.5s5.5 2.467 5.5 5.5-2.467 5.5-5.5 5.5zm5.5-10c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1z" />
      </svg>
    ),
    name: "Android",
    subtitle: "Android 6.0 or later",
    colorClass: "bg-platform-android",
  },
  {
    icon: Apple,
    name: "macOS",
    subtitle: "macOS 10.13 or later",
    colorClass: "bg-platform-macos",
  },
  {
    icon: Monitor,
    name: "Windows",
    subtitle: "Windows 7 or later",
    colorClass: "bg-platform-windows",
  },
  {
    icon: () => (
      <svg className="w-8 h-8" viewBox="0 0 24 24" fill="currentColor">
        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z" />
      </svg>
    ),
    name: "Web Browser",
    subtitle: "Any modern browser",
    colorClass: "bg-platform-web",
  },
  {
    icon: () => (
      <svg className="w-8 h-8" viewBox="0 0 24 24" fill="currentColor">
        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z" />
      </svg>
    ),
    name: "Linux",
    subtitle: "64-bit systems",
    colorClass: "bg-platform-linux",
  },
]

export default function TelegramApps() {
  return (
    <section id="apps" className="py-20 bg-secondary/30">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">Telegram Apps</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Available on all your devices. Synced in real-time.
          </p>
        </motion.div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {platforms.map((platform, index) => (
            <motion.a
              key={platform.name}
              href="#"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: index * 0.05 }}
              viewport={{ once: true }}
              whileHover={{ y: -5 }}
              className="bg-card border border-border rounded-2xl p-5 flex flex-col items-center text-center hover:shadow-lg hover:border-primary/30 transition-all group"
            >
              <div
                className={`w-16 h-16 ${platform.colorClass} rounded-2xl flex items-center justify-center mb-4 text-primary-foreground group-hover:scale-110 transition-transform`}
              >
                {typeof platform.icon === "function" ? <platform.icon /> : <platform.icon className="w-8 h-8" />}
              </div>
              <h3 className="font-semibold text-foreground mb-1">{platform.name}</h3>
              <p className="text-xs text-muted-foreground">{platform.subtitle}</p>
            </motion.a>
          ))}
        </div>
      </div>
    </section>
  )
}
