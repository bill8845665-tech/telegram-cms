"use client"

import { motion } from "framer-motion"

const stats = [
  { value: "950M+", label: "Active Users" },
  { value: "500M+", label: "Daily Messages" },
  { value: "200K", label: "Max Group Size" },
  { value: "2GB", label: "Max File Size" },
]

export default function TelegramStats() {
  return (
    <section className="py-20 bg-primary">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl sm:text-4xl font-bold text-primary-foreground mb-4">Telegram by Numbers</h2>
          <p className="text-lg text-primary-foreground/80">Growing faster than ever</p>
        </motion.div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="text-center"
            >
              <div className="text-4xl sm:text-5xl font-bold text-primary-foreground mb-2">{stat.value}</div>
              <div className="text-primary-foreground/70">{stat.label}</div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
