"use client"

import { motion } from "framer-motion"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Apple, Monitor, Smartphone } from "lucide-react"

export default function TelegramHero() {
  return (
    <section className="pt-32 pb-20 bg-white overflow-hidden">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="text-center">
          {/* Paper Airplane Animation */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="mb-8"
          >
            <div className="w-24 h-24 mx-auto animate-float">
              <Image
                src="/telegram-logo.png"
                alt="Telegram"
                width={96}
                height={96}
                className="w-full h-full drop-shadow-lg"
              />
            </div>
          </motion.div>

          {/* Headlines */}
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-4xl sm:text-5xl lg:text-6xl font-bold text-foreground mb-6 text-balance"
          >
            Telegram
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-xl sm:text-2xl text-muted-foreground mb-4"
          >
            A new era of messaging
          </motion.p>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="text-base text-muted-foreground max-w-xl mx-auto mb-10"
          >
            Fast. Secure. Powerful. Synced across all your devices.
            <br />
            Over 950 million active users.
          </motion.p>

          {/* Download Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="flex flex-wrap justify-center gap-4 mb-8"
          >
            <Button
              size="lg"
              className="bg-primary hover:bg-primary/90 text-primary-foreground rounded-full px-8 gap-2"
            >
              <Smartphone className="w-5 h-5" />
              Telegram for iPhone/iPad
            </Button>
            <Button
              size="lg"
              className="bg-primary hover:bg-primary/90 text-primary-foreground rounded-full px-8 gap-2"
            >
              <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
                <path d="M17.523 2H6.477C4.005 2 2 4.005 2 6.477v11.046C2 19.995 4.005 22 6.477 22h11.046C19.995 22 22 19.995 22 17.523V6.477C22 4.005 19.995 2 17.523 2zM12 17.5c-3.033 0-5.5-2.467-5.5-5.5S8.967 6.5 12 6.5s5.5 2.467 5.5 5.5-2.467 5.5-5.5 5.5zm5.5-10c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1z" />
              </svg>
              Telegram for Android
            </Button>
            <Button
              size="lg"
              className="bg-primary hover:bg-primary/90 text-primary-foreground rounded-full px-8 gap-2"
            >
              <Monitor className="w-5 h-5" />
              Telegram for Windows
            </Button>
            <Button
              size="lg"
              className="bg-primary hover:bg-primary/90 text-primary-foreground rounded-full px-8 gap-2"
            >
              <Apple className="w-5 h-5" />
              Telegram for macOS
            </Button>
          </motion.div>

          {/* Desktop Download Options */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.5 }}
            className="flex flex-wrap justify-center gap-6 text-sm text-muted-foreground mb-16"
          >
            <a href="#" className="flex items-center gap-2 hover:text-primary transition-colors">
              <Monitor className="w-4 h-4" />
              Linux 64 bit
            </a>
            <a href="#" className="flex items-center gap-2 hover:text-primary transition-colors">
              <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z" />
              </svg>
              Web Version
            </a>
          </motion.div>

          {/* Phone Mockup */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="mt-16 max-w-md mx-auto"
          >
            <div className="relative">
              {/* Phone Frame */}
              <div className="bg-foreground rounded-[3rem] p-3 shadow-2xl">
                <div className="bg-background rounded-[2.5rem] overflow-hidden">
                  {/* Status Bar - Updated to use semantic token */}
                  <div className="bg-primary px-6 py-3 flex items-center justify-between">
                    <span className="text-primary-foreground text-sm">9:41</span>
                    <div className="flex gap-1">
                      <div className="w-4 h-2 bg-primary-foreground/80 rounded-sm"></div>
                      <div className="w-4 h-2 bg-primary-foreground/80 rounded-sm"></div>
                      <div className="w-6 h-3 bg-primary-foreground rounded-sm"></div>
                    </div>
                  </div>

                  {/* Chat Header - Updated to use semantic token */}
                  <div className="bg-primary px-4 pb-4 flex items-center gap-3">
                    <div className="w-8 h-8 bg-primary-foreground/20 rounded-full flex items-center justify-center">
                      <svg
                        className="w-5 h-5 text-primary-foreground"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                      </svg>
                    </div>
                    <div className="w-10 h-10 rounded-full overflow-hidden">
                      <Image
                        src="/telegram-logo.png"
                        alt="Telegram"
                        width={40}
                        height={40}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div>
                      <p className="text-primary-foreground font-medium text-sm">Telegram</p>
                      <p className="text-primary-foreground/70 text-xs">950 million users</p>
                    </div>
                  </div>

                  {/* Chat Messages - Updated to use semantic tokens */}
                  <div className="bg-secondary p-4 space-y-3 min-h-[300px]">
                    {/* Received Message */}
                    <div className="flex justify-start">
                      <div className="bg-card rounded-2xl rounded-tl-sm px-4 py-2 max-w-[80%] shadow-sm">
                        <p className="text-foreground text-sm">Welcome to Telegram! The most secure messaging app.</p>
                        <p className="text-xs text-muted-foreground text-right mt-1">09:41</p>
                      </div>
                    </div>

                    {/* Sent Message */}
                    <div className="flex justify-end">
                      <div className="bg-telegram-light-blue rounded-2xl rounded-tr-sm px-4 py-2 max-w-[80%] shadow-sm">
                        <p className="text-foreground text-sm">Amazing! I love the speed and features.</p>
                        <p className="text-xs text-muted-foreground text-right mt-1 flex items-center justify-end gap-1">
                          09:42
                          <svg className="w-4 h-4 text-primary" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41L9 16.17z" />
                          </svg>
                        </p>
                      </div>
                    </div>

                    {/* Received Message */}
                    <div className="flex justify-start">
                      <div className="bg-card rounded-2xl rounded-tl-sm px-4 py-2 max-w-[80%] shadow-sm">
                        <p className="text-foreground text-sm">Version 6.4.1 is now available with new features!</p>
                        <p className="text-xs text-muted-foreground text-right mt-1">09:43</p>
                      </div>
                    </div>
                  </div>

                  {/* Input Bar - Updated to use semantic tokens */}
                  <div className="bg-muted px-4 py-3 flex items-center gap-3">
                    <div className="w-8 h-8 bg-card rounded-full flex items-center justify-center shadow-sm">
                      <svg
                        className="w-5 h-5 text-muted-foreground"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M14.828 14.828a4 4 0 01-5.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                        />
                      </svg>
                    </div>
                    <div className="flex-1 bg-card rounded-full px-4 py-2 text-sm text-muted-foreground">Message</div>
                    <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center shadow-sm">
                      <svg
                        className="w-5 h-5 text-primary-foreground"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z"
                        />
                      </svg>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
